#!/usr/bin/env python3
# Copyright 2025 DataRobot, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Publish the agent's system prompt to DataRobot Prompt Management as a version.

Uses the same SDK surface as the Agent Build Clinic's own
`2 - Prompt Management.ipynb` -- `PromptTemplate.create()` /
`template.create_version()` -- rather than raw REST, since those endpoints are
absent from the public OpenAPI spec.

Run from the project root, after a deploy, so a recorded version corresponds to
a prompt that is actually live:

    cd web && uv run python ../scripts/register_agent_prompt.py

Idempotent: finds the template by exact name, compares the latest version's
text against the source, and writes nothing when they match. That restraint is
the point -- this org already holds 12 templates across 6 distinct names, seven
of them identically named with one version each, because a new template was
created per edit instead of a new version of one. A template with one version
shows no history at all.
"""

from __future__ import annotations

import argparse
import ast
import pathlib
import sys

import datarobot as dr
from datarobot.models.genai.prompt_template import PromptTemplate

TEMPLATE_NAME = "Discharge Recommendation Agent - System Prompt"
TEMPLATE_DESCRIPTION = (
    "System prompt for the recommendation-drafting Agent Deployment in "
    "abc-healthcare-discharge-agent. Versions here track what was deployed."
)

REPO_ROOT = pathlib.Path(__file__).resolve().parent.parent
AGENT_SOURCE = REPO_ROOT / "agent" / "agent" / "myagent.py"
PROMPT_CONSTANT = "RECOMMENDATION_SYSTEM_PROMPT"


def read_prompt_from_source() -> str:
    """Parse the prompt constant out of the agent source without importing it.

    Importing pulls in the agent framework, which is not installed wherever
    this script happens to run.
    """
    tree = ast.parse(AGENT_SOURCE.read_text())
    for node in tree.body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id == PROMPT_CONSTANT:
                    value = ast.literal_eval(node.value)
                    if not isinstance(value, str) or not value.strip():
                        sys.exit(f"{PROMPT_CONSTANT} is not a non-empty string")
                    return value
    sys.exit(f"Could not find {PROMPT_CONSTANT} in {AGENT_SOURCE}")


def find_template() -> PromptTemplate | None:
    matches = [t for t in PromptTemplate.list() if t.name == TEMPLATE_NAME]
    if len(matches) > 1:
        # Precisely the mess this script exists to avoid; refuse to add to it.
        sys.exit(
            f"{len(matches)} templates share the name {TEMPLATE_NAME!r}. "
            "Consolidate them before recording another version."
        )
    return matches[0] if matches else None


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--commit-comment",
        default="Recorded from agent/agent/myagent.py after deploy",
        help="Why this version differs from the previous one.",
    )
    parser.add_argument("--dry-run", action="store_true", help="Report only; write nothing.")
    args = parser.parse_args()

    dr.Client()  # reads DATAROBOT_API_TOKEN / DATAROBOT_ENDPOINT from the environment

    prompt = read_prompt_from_source()
    print(f"prompt: {len(prompt)} chars from {AGENT_SOURCE.relative_to(REPO_ROOT)}")

    template = find_template()
    if template is not None:
        latest = template.get_latest_version()
        if latest is not None and latest.prompt_text == prompt:
            print(
                f"unchanged: {template.id} already at version {latest.version} "
                "-- nothing to record"
            )
            return
        current = f"version {latest.version}" if latest is not None else "no versions yet"
        print(f"template exists: {template.id} ({current})")
    else:
        if args.dry_run:
            print(f"would create template {TEMPLATE_NAME!r} and add version 1")
            return
        template = PromptTemplate.create(name=TEMPLATE_NAME, description=TEMPLATE_DESCRIPTION)
        print(f"created template: {template.id}")

    if args.dry_run:
        print("would append a new version")
        return

    # No variables: this prompt takes none. The per-discharge score, tier and
    # drivers arrive in the user message, not by template substitution.
    version = template.create_version(
        prompt_text=prompt, variables=None, commit_comment=args.commit_comment
    )
    print(f"recorded version {version.version} ({version.id})")


if __name__ == "__main__":
    main()
