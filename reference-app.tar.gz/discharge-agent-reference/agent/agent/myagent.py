# Copyright 2026 DataRobot, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Discharge recommendation-drafting agent: one node, no tools.

The caller (web/app/recommendations/generator.py) sends a single user
message describing one discharge's risk score, risk tier, and grouped
explanation drivers; this agent drafts a narrative and plan-item list as
strict JSON. The caller parses and validates that JSON itself rather than
relying on an LLM-API `response_format` parameter -- untested through this
deployment's chat front end, so not assumed.
"""

from datarobot_genai.core.agents import make_system_prompt
from datarobot_genai.langgraph.agent import datarobot_agent_class_from_langgraph
from langchain.agents import create_agent
from langchain_core.language_models import BaseChatModel
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.tools import BaseTool
from langgraph.graph import END, START, MessagesState, StateGraph

# {topic} is filled by the base LangGraphAgent class from the incoming
# message -- prior turns are replayed as structured history, so this
# intentionally has no {chat_history} placeholder (see agent/tests/test_agent.py).
prompt_template = ChatPromptTemplate.from_messages(
    [
        ("system", "You draft discharge follow-up recommendations for a care team."),
        ("user", "{topic}"),
    ]
)

RECOMMENDATION_SYSTEM_PROMPT = """You draft a discharge follow-up plan for a \
care-coordination team, from a risk score, risk tier, and the model's own top \
driver domains for one discharge -- all given to you in the user message.

Rules:
1. State the risk tier and score as context; do not restate it as your own claim.
2. Ground every sentence only in the driver domains and values given -- never \
invent a clinical detail not present in the input.
3. Write a narrative in plain, clinician-friendly language.
4. Each plan item names one of the given driver domains.
5. Cite the driver's actual value whenever one is given ("2 prior inpatient \
admissions", not "prior utilization"), and keep any timeframe you are given \
exactly as stated.
6. If the user message includes "Required plan items", every one of them must \
appear in your plan_items with its figures and timeframes intact. Reword for \
tone only; never drop or soften one.
7. Do not begin a plan item's text with the driver domain name. The domain is \
already recorded in driver_cited and shown beside the item, so "Medical \
History: Schedule an appointment..." reads as a duplicate. Start with the \
action.
8. Write for a clinician. Never put a raw dataset column name in the text or \
the narrative -- no "number_inpatient", "diag_1_desc" or "medical_specialty". \
Use the wording given for each driver, or plain clinical language. If a driver \
has no value given, describe it qualitatively rather than naming the field.

Scale the plan to the risk tier -- a low-risk discharge does not get the same \
plan as a high-risk one:
- HIGH: 3-5 plan items, a 2-3 sentence narrative. Front-load the earliest \
intervention.
- MEDIUM: 2-3 plan items, a 2 sentence narrative. Routine follow-up timing \
(around 10 days) unless a required item states otherwise.
- LOW: 1-2 plan items, a single sentence narrative. Confirm standard discharge \
instructions and the usual follow-up; do not propose intensive intervention, \
and say plainly that no escalation is indicated.

Respond with ONLY a single JSON object, no markdown fences, no commentary, in \
exactly this shape:
{"narrative": "...", "plan_items": [{"text": "...", "driver_cited": "..."}]}"""


def graph_factory(
    llm: BaseChatModel, tools: list[BaseTool], verbose: bool = False
) -> StateGraph[MessagesState]:
    recommendation_agent = create_agent(
        llm,
        tools=tools,
        system_prompt=make_system_prompt(RECOMMENDATION_SYSTEM_PROMPT),
        name="recommendation_agent",
        debug=verbose,
    )

    langgraph_workflow = StateGraph(MessagesState)
    langgraph_workflow.add_node("recommendation_node", recommendation_agent)
    langgraph_workflow.add_edge(START, "recommendation_node")
    langgraph_workflow.add_edge("recommendation_node", END)
    return langgraph_workflow


MyAgent = datarobot_agent_class_from_langgraph(graph_factory, prompt_template)
