import { useEffect, useState } from 'react';
import {
    fetchFilterOptions,
    fetchPatients,
    fetchSegmentBreakdown,
    fetchSummary,
    fetchTrend,
} from '@/api/cohorts';
import { NextStepHint } from '@/components/block/next-step-hint';
import { EMPTY_FILTERS, Filters } from '@/components/cohort/Filters';
import { PatientTable } from '@/components/cohort/PatientTable';
import { SegmentChart } from '@/components/cohort/SegmentChart';
import { SummaryCards } from '@/components/cohort/SummaryCards';
import { TrendChart } from '@/components/cohort/TrendChart';
import type {
    CohortFilterOptions,
    CohortFilterState,
    CohortSummary,
    PatientRow,
    SegmentDimension,
    SegmentPoint,
    TrendPoint,
} from '@/types/cohort';

const PAGE_SIZE = 20;

function formatMonthYear(isoDate: string): string {
    const date = new Date(`${isoDate}T00:00:00`);
    return date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
}

export function Dashboard() {
    const [options, setOptions] = useState<CohortFilterOptions | null>(null);
    const [filters, setFilters] = useState<CohortFilterState>(EMPTY_FILTERS);
    const [dimension, setDimension] = useState<SegmentDimension>('race');

    const [summary, setSummary] = useState<CohortSummary | null>(null);
    const [trend, setTrend] = useState<TrendPoint[]>([]);
    const [segments, setSegments] = useState<SegmentPoint[]>([]);

    const [patientRows, setPatientRows] = useState<PatientRow[]>([]);
    const [patientTotal, setPatientTotal] = useState(0);
    const [offset, setOffset] = useState(0);
    const [sortBy, setSortBy] = useState('admission_date');
    const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');

    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        fetchFilterOptions()
            .then(setOptions)
            .catch(() => setError('Could not load filter options.'));
    }, []);

    useEffect(() => {
        let cancelled = false;
        Promise.all([
            fetchSummary(filters),
            fetchTrend(filters),
            fetchSegmentBreakdown(dimension, filters),
        ])
            .then(([summaryData, trendData, segmentData]) => {
                if (cancelled) return;
                setSummary(summaryData);
                setTrend(trendData);
                setSegments(segmentData);
                setError(null);
            })
            .catch(() => {
                if (!cancelled) setError('Could not load cohort data. Retry shortly.');
            });
        return () => {
            cancelled = true;
        };
    }, [filters, dimension]);

    useEffect(() => {
        setOffset(0);
    }, [filters]);

    useEffect(() => {
        let cancelled = false;
        fetchPatients(filters, { offset, limit: PAGE_SIZE, sortBy, sortDir })
            .then(page => {
                if (cancelled) return;
                setPatientRows(page.rows);
                setPatientTotal(page.total);
            })
            .catch(() => {
                if (!cancelled) setError('Could not load patient history. Retry shortly.');
            });
        return () => {
            cancelled = true;
        };
    }, [filters, offset, sortBy, sortDir]);

    function handleSortChange(column: string) {
        if (column === sortBy) {
            setSortDir(previous => (previous === 'asc' ? 'desc' : 'asc'));
        } else {
            setSortBy(column);
            setSortDir('desc');
        }
    }

    const dateRangeLabel =
        summary?.date_min && summary?.date_max
            ? `${formatMonthYear(summary.date_min)}–${formatMonthYear(summary.date_max)}`
            : null;

    return (
        <div className="mx-auto max-w-6xl space-y-6 p-6">
            <header>
                <h1 className="heading-03">Readmission cohorts &amp; history</h1>
                <p className="body-secondary mt-1">
                    High-risk diabetes discharge cohort — 30-day readmission history
                    {dateRangeLabel ? `, ${dateRangeLabel}` : ''}. No predictions are made on this
                    page.
                </p>
            </header>

            <NextStepHint id="dashboard">
                This page is historical outcomes only. Open <strong>Discharges for today</strong>{' '}
                above to see today&rsquo;s patients with their predicted risk, or use{' '}
                <strong>Ask about the cohort</strong> to question any trend here in plain language.
            </NextStepHint>

            {error ? (
                <p
                    role="alert"
                    className="border-destructive text-destructive rounded-md border p-3 text-sm"
                >
                    {error}
                </p>
            ) : null}

            <Filters options={options} filters={filters} onChange={setFilters} />

            <SummaryCards summary={summary} dateRangeLabel={dateRangeLabel} />

            <div className="grid gap-6 lg:grid-cols-2">
                <TrendChart
                    data={trend}
                    baselineRate={summary?.baseline_rate ?? 0.3965}
                    dateRangeLabel={dateRangeLabel}
                />
                <SegmentChart
                    dimension={dimension}
                    onDimensionChange={setDimension}
                    data={segments}
                    baselineRate={summary?.baseline_rate ?? 0.3965}
                />
            </div>

            <PatientTable
                rows={patientRows}
                total={patientTotal}
                offset={offset}
                limit={PAGE_SIZE}
                sortBy={sortBy}
                sortDir={sortDir}
                onSortChange={handleSortChange}
                onPageChange={setOffset}
            />
        </div>
    );
}
