import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

import { fetchQueue } from '@/api/discharges';
import { NextStepHint } from '@/components/block/next-step-hint';
import { RiskBadge } from '@/components/discharge/RiskBadge';
import type { Queue } from '@/types/discharge';

export function DischargeQueue() {
    const [queue, setQueue] = useState<Queue | null>(null);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        let cancelled = false;
        fetchQueue()
            .then(data => {
                if (!cancelled) setQueue(data);
            })
            .catch(() => {
                if (!cancelled) setError("Could not load today's discharge queue. Retry shortly.");
            });
        return () => {
            cancelled = true;
        };
    }, []);

    return (
        <div className="mx-auto max-w-6xl space-y-6 p-6">
            <header>
                <h1 className="heading-03">Discharges for today</h1>
                {queue ? (
                    <p className="body-secondary mt-1">
                        Showing a simulated &ldquo;as of&rdquo; slice: {queue.as_of_date} — the date
                        in the prediction pool closest to today, not the real current date. The pool
                        is a fixed dataset, so this stands in for a live discharge feed.
                    </p>
                ) : null}
            </header>

            <NextStepHint id="queue">
                Highest risk is listed first. Choose <strong>View details</strong> on any patient to
                see which factors drove their score, try a hypothetical change, and draft a
                follow-up plan for review.
            </NextStepHint>

            {error ? (
                <p
                    role="alert"
                    className="border-destructive text-destructive rounded-md border p-3 text-sm"
                >
                    {error}
                </p>
            ) : null}

            {!queue && !error ? (
                <p className="body-secondary" role="status">
                    Loading today&rsquo;s discharge queue — the first load after a deploy can take a
                    couple of minutes, while risk scores are computed for the full pool.
                </p>
            ) : null}

            {queue ? (
                <section
                    aria-labelledby="queue-heading"
                    className="border-border bg-card rounded-lg border p-4"
                >
                    <h2 id="queue-heading" className="sr-only">
                        Discharge queue
                    </h2>
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                            <caption className="sr-only">
                                Today&rsquo;s discharges, sorted by risk score, highest first
                            </caption>
                            <thead>
                                <tr className="border-border border-b text-left">
                                    <th scope="col" className="py-2 pr-4">
                                        Patient
                                    </th>
                                    <th scope="col" className="py-2 pr-4">
                                        Admitted
                                    </th>
                                    <th scope="col" className="py-2 pr-4">
                                        Discharged
                                    </th>
                                    <th scope="col" className="py-2 pr-4">
                                        Age
                                    </th>
                                    <th scope="col" className="py-2 pr-4">
                                        Risk tier
                                    </th>
                                    <th scope="col" className="py-2 pr-4">
                                        Risk score
                                    </th>
                                    <th scope="col" className="py-2">
                                        <span className="sr-only">Details</span>
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                {queue.rows.map(row => (
                                    <tr
                                        key={row.association_id}
                                        className="border-border/50 border-b"
                                    >
                                        <td className="py-2 pr-4">{row.patient_id}</td>
                                        <td className="py-2 pr-4 whitespace-nowrap">
                                            {row.admission_date}
                                        </td>
                                        <td className="py-2 pr-4 whitespace-nowrap">
                                            {row.discharge_date}
                                        </td>
                                        <td className="py-2 pr-4">{row.age}</td>
                                        <td className="py-2 pr-4">
                                            <RiskBadge tier={row.risk_tier} />
                                        </td>
                                        <td className="py-2 pr-4">
                                            {row.risk_score !== null
                                                ? `${(row.risk_score * 100).toFixed(1)}%`
                                                : '—'}
                                        </td>
                                        <td className="py-2">
                                            <Link
                                                to={`/discharges/${encodeURIComponent(row.association_id)}`}
                                                className="text-primary hover:text-accent underline"
                                            >
                                                View details
                                            </Link>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                    {queue.rows.length === 0 ? (
                        <p className="body-secondary mt-2">
                            No discharges scheduled for this date.
                        </p>
                    ) : null}
                </section>
            ) : null}
        </div>
    );
}
