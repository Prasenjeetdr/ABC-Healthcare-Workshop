import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';

import { fetchDischarge, fetchFeatureSchema } from '@/api/discharges';
import { NextStepHint } from '@/components/block/next-step-hint';
import { ExplanationPanel } from '@/components/discharge/ExplanationPanel';
import { FeedbackControl } from '@/components/feedback/FeedbackControl';
import { RecommendationPanel } from '@/components/discharge/RecommendationPanel';
import { RiskBadge } from '@/components/discharge/RiskBadge';
import { WhatIfPanel } from '@/components/discharge/WhatIfPanel';
import type { FeatureSchema, ScoreResult } from '@/types/discharge';

function formatPercent(value: number): string {
    return `${(value * 100).toFixed(1)}%`;
}

// association_id is a synthetic "{patient_id}|{discharge_date}" compound key
// (see QueueRow) -- split it back apart for a heading a clinician can read.
function formatHeading(associationId: string): string {
    const [patientId, dischargeDate] = associationId.split('|');
    if (!dischargeDate) return `Discharge ${associationId}`;
    return `Patient ${patientId} — discharged ${dischargeDate}`;
}

export function PatientDetail() {
    const { associationId } = useParams<{ associationId: string }>();
    const [result, setResult] = useState<ScoreResult | null>(null);
    const [featureSchema, setFeatureSchema] = useState<FeatureSchema | null>(null);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        if (!associationId) return;
        let cancelled = false;
        setResult(null);
        setError(null);
        Promise.all([fetchDischarge(associationId), fetchFeatureSchema()])
            .then(([scoreResult, schema]) => {
                if (cancelled) return;
                setResult(scoreResult);
                setFeatureSchema(schema);
            })
            .catch(() => {
                if (!cancelled) setError('Could not load this discharge. Retry shortly.');
            });
        return () => {
            cancelled = true;
        };
    }, [associationId]);

    return (
        <div className="mx-auto max-w-6xl space-y-6 p-6">
            <Link to="/discharges" className="text-primary hover:text-accent text-sm underline">
                ← Back to discharge queue
            </Link>

            <header>
                <h1 className="heading-03">
                    {associationId ? formatHeading(associationId) : 'Discharge'}
                </h1>
            </header>

            {error ? (
                <p
                    role="alert"
                    className="border-destructive text-destructive rounded-md border p-3 text-sm"
                >
                    {error}
                </p>
            ) : null}

            {!result && !error ? (
                <p className="body-secondary" role="status">
                    Loading risk score and explanation…
                </p>
            ) : null}

            {result ? (
                <>
                    <NextStepHint id="detail">
                        Below: why the model scored this discharge, a <strong>what-if</strong> to
                        test a hypothetical change, and <strong>Draft recommendation</strong> to
                        have the agent propose a follow-up plan you can approve, edit or reject.
                    </NextStepHint>

                    <section
                        aria-labelledby="score-heading"
                        className="border-border bg-card rounded-lg border p-4"
                    >
                        <h2 id="score-heading" className="sr-only">
                            Risk score
                        </h2>
                        <div className="flex flex-wrap items-center gap-4">
                            <p className="heading-01">{formatPercent(result.risk_score)}</p>
                            <RiskBadge tier={result.risk_tier} />
                            <p className="body-secondary">
                                30-day readmission risk, vs. 39.65% cohort baseline
                            </p>
                        </div>
                    </section>

                    <div className="border-border bg-card rounded-lg border p-4">
                        <ExplanationPanel groupedExplanations={result.grouped_explanations} />
                        {associationId ? (
                            <FeedbackControl
                                subjectType="risk_score"
                                subjectId={associationId}
                                associationId={associationId}
                                label="risk score"
                                className="mt-4"
                            />
                        ) : null}
                    </div>

                    {featureSchema && associationId ? (
                        <WhatIfPanel associationId={associationId} featureSchema={featureSchema} />
                    ) : null}

                    {associationId ? <RecommendationPanel associationId={associationId} /> : null}
                </>
            ) : null}
        </div>
    );
}
