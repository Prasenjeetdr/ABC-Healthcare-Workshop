/*
 * Copyright 2025 DataRobot, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { NavLink, Route, Routes } from 'react-router-dom';

import { ThemeToggle } from '@/components/block/theme-toggle';
import { ChatWidget } from '@/components/chat/ChatPanel';
import { cn } from '@/lib/utils';
import { Dashboard } from '@/pages/Dashboard';
import { DischargeQueue } from '@/pages/DischargeQueue';
import { PatientDetail } from '@/pages/PatientDetail';

// Tabs sit on the content's baseline: -mb-px pulls each one over the header's
// bottom border so the active tab's underline reads as a selected tab rather
// than a detached accent.
const NAV_LINK_CLASS = ({ isActive }: { isActive: boolean }) =>
    cn(
        '-mb-px border-b-2 px-4 py-3 text-base',
        isActive
            ? 'border-accent text-foreground font-semibold'
            : 'body-secondary hover:text-foreground border-transparent'
    );

function App() {
    return (
        <>
            {/* Same container as every page, so the tabs line up with the
                content's left edge instead of drifting to the window edge on
                a wide screen. */}
            <header className="border-border border-b">
                <div className="mx-auto flex max-w-6xl items-center justify-between gap-2 px-6">
                    <nav aria-label="Primary" className="flex gap-1">
                        <NavLink to="/" end className={NAV_LINK_CLASS}>
                            Cohort dashboard
                        </NavLink>
                        <NavLink to="/discharges" className={NAV_LINK_CLASS}>
                            Discharges for today
                        </NavLink>
                    </nav>
                    <div className="flex items-center gap-1">
                        <ChatWidget />
                        <ThemeToggle />
                    </div>
                </div>
            </header>
            <Routes>
                <Route path="/" element={<Dashboard />} />
                <Route path="/discharges" element={<DischargeQueue />} />
                <Route path="/discharges/:associationId" element={<PatientDetail />} />
            </Routes>
        </>
    );
}

export default App;
