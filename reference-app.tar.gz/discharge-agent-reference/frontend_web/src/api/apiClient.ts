import axios from 'axios';
import axiosRetry from 'axios-retry';

import { getApiUrl } from '@/lib/utils';

const baseApiUrl = getApiUrl();

// Without a timeout, axios waits indefinitely, so a request that stalls
// rather than fails -- one in flight when the app's container is replaced,
// for instance -- never rejects and never reaches the retry logic below. The
// calling page then sits on its loading state forever with no way out.
const DEFAULT_TIMEOUT_MS = 30_000;

// The discharge queue is the one endpoint that legitimately runs long: on a
// cold cache it triggers a full batch scoring job, measured at ~95s. It needs
// its own budget, and it must not be retried on timeout -- five more requests
// would each start behind the same job.
export const LONG_RUNNING_TIMEOUT_MS = 180_000;

const apiClient = axios.create({
    baseURL: baseApiUrl,
    timeout: DEFAULT_TIMEOUT_MS,
    headers: {
        Accept: 'application/json',
        'Content-type': 'application/json',
    },
    withCredentials: true,
});

axiosRetry(apiClient, {
    retries: 5,
    retryDelay: axiosRetry.exponentialDelay,
});

/** True when a request failed because the resource is gone (HTTP 404). */
export function isNotFoundError(error: unknown): boolean {
    return axios.isAxiosError(error) && error.response?.status === 404;
}

export default apiClient;
