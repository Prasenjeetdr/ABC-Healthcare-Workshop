import apiClient, { isNotFoundError, LONG_RUNNING_TIMEOUT_MS } from '@/api/apiClient';
import type {
    FeatureSchema,
    PlanItem,
    Queue,
    Recommendation,
    ScoreResult,
    WhatIfResult,
} from '@/types/discharge';

export async function fetchQueue(): Promise<Queue> {
    // Long budget, and no retry: a timeout here means the batch job is still
    // running server-side, so retrying only queues more requests behind it.
    const response = await apiClient.get<Queue>('/v1/discharges/queue', {
        timeout: LONG_RUNNING_TIMEOUT_MS,
        'axios-retry': { retries: 0 },
    });
    return response.data;
}

export async function fetchFeatureSchema(): Promise<FeatureSchema> {
    const response = await apiClient.get<FeatureSchema>('/v1/discharges/feature-schema');
    return response.data;
}

export async function fetchDischarge(associationId: string): Promise<ScoreResult> {
    const response = await apiClient.get<ScoreResult>(
        `/v1/discharges/${encodeURIComponent(associationId)}`
    );
    return response.data;
}

export async function postWhatIf(
    associationId: string,
    overrides: Record<string, string | number>
): Promise<WhatIfResult> {
    const response = await apiClient.post<WhatIfResult>(
        `/v1/discharges/${encodeURIComponent(associationId)}/what-if`,
        { overrides }
    );
    return response.data;
}

export async function draftRecommendation(associationId: string): Promise<Recommendation> {
    // Calls the Agent Deployment, which takes ~15s and can run longer for a
    // HIGH-tier plan. A client-side timeout here is worse than a slow wait:
    // the server would still finish and persist a row the user never sees,
    // and drafting again would create a second one.
    const response = await apiClient.post<Recommendation>(
        `/v1/discharges/${encodeURIComponent(associationId)}/recommendation`,
        undefined,
        { timeout: LONG_RUNNING_TIMEOUT_MS }
    );
    return response.data;
}

export async function fetchRecommendation(associationId: string): Promise<Recommendation | null> {
    try {
        const response = await apiClient.get<Recommendation>(
            `/v1/discharges/${encodeURIComponent(associationId)}/recommendation`
        );
        return response.data;
    } catch (error) {
        if (isNotFoundError(error)) {
            return null;
        }
        throw error;
    }
}

export async function actionRecommendation(
    associationId: string,
    recommendationId: string,
    action: 'approve' | 'edit' | 'reject',
    editedPlanItems?: PlanItem[]
): Promise<Recommendation> {
    const response = await apiClient.post<Recommendation>(
        `/v1/discharges/${encodeURIComponent(associationId)}/recommendation/${encodeURIComponent(recommendationId)}/action`,
        { action, edited_plan_items: editedPlanItems }
    );
    return response.data;
}
