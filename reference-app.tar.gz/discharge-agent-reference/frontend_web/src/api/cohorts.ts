import apiClient from '@/api/apiClient';
import type {
    CohortFilterOptions,
    CohortFilterState,
    CohortSummary,
    PatientPage,
    SegmentDimension,
    SegmentPoint,
    TrendPoint,
} from '@/types/cohort';

function buildParams(filters: CohortFilterState): URLSearchParams {
    const params = new URLSearchParams();
    if (filters.start_date) params.append('start_date', filters.start_date);
    if (filters.end_date) params.append('end_date', filters.end_date);
    for (const race of filters.race) params.append('race', race);
    for (const gender of filters.gender) params.append('gender', gender);
    for (const age of filters.age) params.append('age', age);
    for (const value of filters.discharge_disposition_id) {
        params.append('discharge_disposition_id', value);
    }
    for (const value of filters.admission_type_id) {
        params.append('admission_type_id', value);
    }
    return params;
}

export async function fetchFilterOptions(): Promise<CohortFilterOptions> {
    const response = await apiClient.get<CohortFilterOptions>('/v1/cohorts/filters');
    return response.data;
}

export async function fetchSummary(filters: CohortFilterState): Promise<CohortSummary> {
    const response = await apiClient.get<CohortSummary>('/v1/cohorts/summary', {
        params: buildParams(filters),
    });
    return response.data;
}

export async function fetchTrend(filters: CohortFilterState): Promise<TrendPoint[]> {
    const response = await apiClient.get<TrendPoint[]>('/v1/cohorts/trend', {
        params: buildParams(filters),
    });
    return response.data;
}

export async function fetchSegmentBreakdown(
    dimension: SegmentDimension,
    filters: CohortFilterState
): Promise<SegmentPoint[]> {
    const response = await apiClient.get<SegmentPoint[]>(`/v1/cohorts/segments/${dimension}`, {
        params: buildParams(filters),
    });
    return response.data;
}

export interface PatientQuery {
    offset: number;
    limit: number;
    sortBy: string;
    sortDir: 'asc' | 'desc';
}

export async function fetchPatients(
    filters: CohortFilterState,
    query: PatientQuery
): Promise<PatientPage> {
    const params = buildParams(filters);
    params.append('offset', String(query.offset));
    params.append('limit', String(query.limit));
    params.append('sort_by', query.sortBy);
    params.append('sort_dir', query.sortDir);
    const response = await apiClient.get<PatientPage>('/v1/patients', { params });
    return response.data;
}
