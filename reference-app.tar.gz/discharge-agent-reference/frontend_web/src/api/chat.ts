import apiClient from '@/api/apiClient';
import type { ChatMessage } from '@/types/chat';

export async function postChatMessage(messages: ChatMessage[]): Promise<ChatMessage> {
    const response = await apiClient.post<ChatMessage>('/v1/cohorts/chat', { messages });
    return response.data;
}
