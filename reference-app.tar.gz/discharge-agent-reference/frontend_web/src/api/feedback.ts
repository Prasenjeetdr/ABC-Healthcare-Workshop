import apiClient from '@/api/apiClient';
import type { FeedbackRecord, FeedbackStatus, FeedbackSubjectType } from '@/types/feedback';

export async function submitFeedback(input: {
    subject_type: FeedbackSubjectType;
    subject_id: string;
    association_id?: string | null;
    sentiment: 'up' | 'down';
    comment?: string | null;
}): Promise<FeedbackRecord> {
    const response = await apiClient.post<FeedbackRecord>('/v1/feedback', input);
    return response.data;
}

// Null is the normal answer for most subjects -- nobody has an opinion on most
// of them -- so this resolves to null rather than throwing.
export async function fetchFeedback(
    subjectType: FeedbackSubjectType,
    subjectId: string
): Promise<FeedbackRecord | null> {
    const response = await apiClient.get<FeedbackRecord | null>('/v1/feedback', {
        params: { subject_type: subjectType, subject_id: subjectId },
    });
    return response.data ?? null;
}

export async function fetchFeedbackStatus(): Promise<FeedbackStatus> {
    const response = await apiClient.get<FeedbackStatus>('/v1/feedback/status');
    return response.data;
}
