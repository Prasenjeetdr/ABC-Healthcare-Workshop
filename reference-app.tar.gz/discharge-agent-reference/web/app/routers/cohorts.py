# Copyright 2025 DataRobot, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Phase 1 endpoints: readmission cohort overview and history (no predictions)."""

from datetime import date
from typing import Annotated

import pandas as pd
from fastapi import APIRouter, HTTPException, Query, Request

from app.config import Config
from app.cohorts import data

router = APIRouter(prefix="/api/v1", tags=["cohorts"])


def get_config(request: Request) -> Config:
    return request.app.state.deps.config


SegmentFilter = Annotated[list[str] | None, Query()]


def _build_filters(
    start_date: date | None,
    end_date: date | None,
    race: SegmentFilter,
    gender: SegmentFilter,
    age: SegmentFilter,
    discharge_disposition_id: SegmentFilter,
    admission_type_id: SegmentFilter,
) -> data.HistoryFilters:
    return data.HistoryFilters(
        start_date=pd.Timestamp(start_date) if start_date else None,
        end_date=pd.Timestamp(end_date) if end_date else None,
        race=tuple(race) if race else None,
        gender=tuple(gender) if gender else None,
        age=tuple(age) if age else None,
        discharge_disposition_id=(
            tuple(discharge_disposition_id) if discharge_disposition_id else None
        ),
        admission_type_id=tuple(admission_type_id) if admission_type_id else None,
    )


@router.get("/cohorts/filters")
async def get_filter_options(request: Request) -> dict[str, object]:
    config = get_config(request)
    df = data.get_history_dataframe(config)
    return data.filter_options(df)


@router.get("/cohorts/summary")
async def get_summary(
    request: Request,
    start_date: date | None = None,
    end_date: date | None = None,
    race: SegmentFilter = None,
    gender: SegmentFilter = None,
    age: SegmentFilter = None,
    discharge_disposition_id: SegmentFilter = None,
    admission_type_id: SegmentFilter = None,
) -> dict[str, object]:
    config = get_config(request)
    filters = _build_filters(
        start_date, end_date, race, gender, age, discharge_disposition_id, admission_type_id
    )
    df = data.apply_filters(data.get_history_dataframe(config), filters)
    return data.summarize(df)


@router.get("/cohorts/trend")
async def get_trend(
    request: Request,
    start_date: date | None = None,
    end_date: date | None = None,
    race: SegmentFilter = None,
    gender: SegmentFilter = None,
    age: SegmentFilter = None,
    discharge_disposition_id: SegmentFilter = None,
    admission_type_id: SegmentFilter = None,
) -> list[dict[str, object]]:
    config = get_config(request)
    filters = _build_filters(
        start_date, end_date, race, gender, age, discharge_disposition_id, admission_type_id
    )
    df = data.apply_filters(data.get_history_dataframe(config), filters)
    return data.monthly_trend(df)


@router.get("/cohorts/segments/{dimension}")
async def get_segment_breakdown(
    dimension: str,
    request: Request,
    start_date: date | None = None,
    end_date: date | None = None,
    race: SegmentFilter = None,
    gender: SegmentFilter = None,
    age: SegmentFilter = None,
    discharge_disposition_id: SegmentFilter = None,
    admission_type_id: SegmentFilter = None,
) -> list[dict[str, object]]:
    if dimension not in data.SEGMENT_DIMENSIONS:
        raise HTTPException(status_code=404, detail=f"Unknown segment dimension: {dimension}")

    config = get_config(request)
    filters = _build_filters(
        start_date, end_date, race, gender, age, discharge_disposition_id, admission_type_id
    )
    df = data.apply_filters(data.get_history_dataframe(config), filters)
    return data.segment_breakdown(df, dimension)


@router.get("/patients")
async def get_patients(
    request: Request,
    offset: int = 0,
    limit: int = 25,
    sort_by: str = "admission_date",
    sort_dir: str = "desc",
    start_date: date | None = None,
    end_date: date | None = None,
    race: SegmentFilter = None,
    gender: SegmentFilter = None,
    age: SegmentFilter = None,
    discharge_disposition_id: SegmentFilter = None,
    admission_type_id: SegmentFilter = None,
) -> dict[str, object]:
    config = get_config(request)
    filters = _build_filters(
        start_date, end_date, race, gender, age, discharge_disposition_id, admission_type_id
    )
    df = data.apply_filters(data.get_history_dataframe(config), filters)
    limit = max(1, min(limit, 100))
    rows, total = data.patient_rows(df, offset, limit, sort_by, sort_dir)
    return {"rows": rows, "total": total, "offset": offset, "limit": limit}
