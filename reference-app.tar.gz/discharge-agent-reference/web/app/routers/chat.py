# Copyright 2025 DataRobot, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Phase 2 endpoint: chat over the cohort's historical trends.

Stateless -- conversation state lives in the frontend and is sent with each
call, not stored server-side. Reloading the page clears it; that's
deliberate, not an oversight (see full_stack_spec.md's Out of scope).
"""

import uuid
from typing import Literal

from fastapi import APIRouter, Request
from pydantic import BaseModel

from app.chat.agent import chat as run_chat
from app.config import Config

router = APIRouter(prefix="/api/v1", tags=["chat"])


def get_config(request: Request) -> Config:
    return request.app.state.deps.config


class ChatMessage(BaseModel):
    role: Literal["user", "assistant"]
    content: str


class ChatRequest(BaseModel):
    messages: list[ChatMessage]


class ChatResponse(BaseModel):
    role: Literal["assistant"] = "assistant"
    content: str
    # Server-generated so feedback can identify which reply was judged. The
    # endpoint is stateless, so an array index would move under the client's
    # feet as the conversation grows.
    message_id: str


@router.post("/cohorts/chat")
async def post_chat(body: ChatRequest, request: Request) -> ChatResponse:
    config = get_config(request)
    messages = [m.model_dump() for m in body.messages]
    reply = await run_chat(messages, config)
    return ChatResponse(content=reply, message_id=str(uuid.uuid4()))
