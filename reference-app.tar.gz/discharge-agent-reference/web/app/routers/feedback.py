# Copyright 2025 DataRobot, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Feedback endpoints.

The write path is deliberately ordered: record locally, then emit. A
clinician's click succeeds even when the governance side-channel is
misconfigured, and `emitted` in the response tells the truth about which
happened.
"""

from __future__ import annotations

from typing import Any, Literal

import aiosqlite
from fastapi import APIRouter, Request
from pydantic import BaseModel, Field

from app.config import Config
from app.feedback import db as feedback_db
from app.feedback import emitter

router = APIRouter(prefix="/api/v1/feedback", tags=["feedback"])


def get_config(request: Request) -> Config:
    config: Config = request.app.state.deps.config
    return config


def get_conn(request: Request) -> aiosqlite.Connection:
    # Shares the recommendations connection on purpose -- see feedback/db.py.
    conn: aiosqlite.Connection = request.app.state.deps.recommendations_conn
    return conn


class FeedbackRequest(BaseModel):
    subject_type: Literal["risk_score", "recommendation", "chat_answer"]
    subject_id: str = Field(min_length=1, max_length=200)
    association_id: str | None = None
    sentiment: Literal["up", "down"]
    # Clinician prose about the app's output. Bounded so it cannot become a
    # dumping ground, and it is the only free text this app stores.
    comment: str | None = Field(default=None, max_length=2000)


@router.post("")
async def post_feedback(body: FeedbackRequest, request: Request) -> dict[str, Any]:
    config = get_config(request)
    conn = get_conn(request)

    record = await feedback_db.upsert(
        conn,
        subject_type=body.subject_type,
        subject_id=body.subject_id,
        association_id=body.association_id,
        sentiment=body.sentiment,
        comment=body.comment,
    )

    # Always traceable; the metric only when the deployment defines it.
    emitter.emit_span(record)
    if await emitter.emit_metric(config, record):
        await feedback_db.mark_emitted(conn, record["id"])
        record["emitted"] = True

    return record


@router.get("")
async def get_feedback(
    subject_type: Literal["risk_score", "recommendation", "chat_answer"],
    subject_id: str,
    request: Request,
) -> dict[str, Any] | None:
    """Null rather than 404 when nothing was said: "no opinion yet" is a
    normal state for every subject in the app, and a 404 would make the
    frontend treat the common case as an error."""
    return await feedback_db.get(
        get_conn(request), subject_type=subject_type, subject_id=subject_id
    )


@router.get("/status")
async def get_status(request: Request) -> dict[str, Any]:
    """Which channels are live, plus this app's own tally. Lets the UI name a
    real destination instead of implying a metric that may not exist."""
    status = await emitter.channel_status(get_config(request))
    status["local_counts"] = await feedback_db.counts(get_conn(request))
    return status
