# Copyright 2025 DataRobot, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Phase 3 endpoints: today's discharge queue, real-time score + explain,
manual entry, and what-if. Every score in this router comes from the same
`scoring.score_and_explain` -- it can never disagree with itself."""

from typing import Any, Literal

import aiosqlite
from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

from app.config import Config
from app.discharges import data, feature_groups, scoring
from app.recommendations import db as recommendations_db
from app.recommendations import generator

router = APIRouter(prefix="/api/v1/discharges", tags=["discharges"])


def get_config(request: Request) -> Config:
    return request.app.state.deps.config


def get_recommendations_conn(request: Request) -> aiosqlite.Connection:
    return request.app.state.deps.recommendations_conn


def _with_grouped_explanations(result: dict[str, Any]) -> dict[str, Any]:
    result["grouped_explanations"] = feature_groups.group_explanations(result["explanations"])
    return result


@router.get("/queue")
async def get_queue(request: Request) -> dict[str, Any]:
    """Today's discharges, prescored -- the as-of date is a chosen,
    labeled-as-simulated slice of the pool, never the real current date."""
    config = get_config(request)
    as_of_date = data.resolve_as_of_date(config)
    rows = await data.get_queue(config, as_of_date)
    return {"as_of_date": as_of_date, "rows": rows}


@router.get("/feature-schema")
async def get_feature_schema(request: Request) -> dict[str, Any]:
    """The deployment's real feature schema -- backs the manual-entry
    form's field set and the what-if field picker.

    Each feature carries a `label`, so the frontend renders the
    clinician-facing name without keeping its own copy of the mapping.
    """
    config = get_config(request)
    info = await feature_groups.get_deployment_info(config)
    return {
        **info,
        "features": [
            {**feature, "label": feature_groups.display_name(feature["name"])}
            for feature in info["features"]
        ],
    }


@router.get("/{association_id}")
async def get_discharge(association_id: str, request: Request) -> dict[str, Any]:
    config = get_config(request)
    try:
        features = await data.get_patient_features(config, association_id)
    except KeyError:
        raise HTTPException(status_code=404, detail="Discharge not found")
    result = await scoring.score_and_explain(config, features)
    return _with_grouped_explanations(result)


class ScoreRequest(BaseModel):
    features: dict[str, Any]


@router.post("/score")
async def post_score(body: ScoreRequest, request: Request) -> dict[str, Any]:
    """Manual entry -- `features` should match the manual-entry form's
    field set, sourced from /feature-schema."""
    config = get_config(request)
    result = await scoring.score_and_explain(config, body.features)
    return _with_grouped_explanations(result)


class WhatIfRequest(BaseModel):
    overrides: dict[str, Any]


@router.post("/{association_id}/what-if")
async def post_what_if(
    association_id: str, body: WhatIfRequest, request: Request
) -> dict[str, Any]:
    """Hypothetical only -- the result is never logged as a real prediction
    and never feeds the recommendation generator."""
    config = get_config(request)
    try:
        features = await data.get_patient_features(config, association_id)
    except KeyError:
        raise HTTPException(status_code=404, detail="Discharge not found")
    result = await scoring.what_if(config, features, body.overrides)
    _with_grouped_explanations(result["baseline"])
    _with_grouped_explanations(result["adjusted"])
    return result


# --- Phase 4: recommendation triage ------------------------------------------


@router.post("/{association_id}/recommendation")
async def post_recommendation(association_id: str, request: Request) -> dict[str, Any]:
    """Draft + persist. Always scores fresh first -- a recommendation is
    never drafted from a stale/what-if score, only a real one."""
    config = get_config(request)
    conn = get_recommendations_conn(request)
    try:
        features = await data.get_patient_features(config, association_id)
    except KeyError:
        raise HTTPException(status_code=404, detail="Discharge not found")

    scored = await scoring.score_and_explain(config, features)
    grouped = feature_groups.group_explanations(scored["explanations"])
    drafted = await generator.draft_recommendation(
        config,
        scored["risk_score"],
        scored["risk_tier"],
        grouped,
        features,
        association_id=association_id,
    )
    return await recommendations_db.insert_recommendation(
        conn,
        association_id=association_id,
        risk_score=scored["risk_score"],
        risk_tier=scored["risk_tier"],
        drivers=grouped,
        narrative=drafted["narrative"],
        plan_items=drafted["plan_items"],
    )


@router.get("/{association_id}/recommendation")
async def get_recommendation(association_id: str, request: Request) -> dict[str, Any]:
    """The persisted state, so a reload doesn't lose it -- the one place in
    this app where reload-durability matters."""
    conn = get_recommendations_conn(request)
    result = await recommendations_db.get_latest_for_association(conn, association_id)
    if result is None:
        raise HTTPException(status_code=404, detail="No recommendation drafted yet")
    return result


class RecommendationActionRequest(BaseModel):
    action: Literal["approve", "edit", "reject"]
    edited_plan_items: list[dict[str, Any]] | None = None


@router.post("/{association_id}/recommendation/{recommendation_id}/action")
async def post_recommendation_action(
    association_id: str,
    recommendation_id: str,
    body: RecommendationActionRequest,
    request: Request,
) -> dict[str, Any]:
    """Plain DB write, no LLM call -- status only ever changes here, never
    automatically."""
    conn = get_recommendations_conn(request)
    existing = await recommendations_db.get_by_id(conn, recommendation_id)
    if existing is None or existing["association_id"] != association_id:
        raise HTTPException(status_code=404, detail="Recommendation not found")

    result = await recommendations_db.apply_action(
        conn, recommendation_id, body.action, body.edited_plan_items
    )
    assert result is not None
    return result
