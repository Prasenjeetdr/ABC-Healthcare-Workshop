# Copyright 2025 DataRobot, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""LiteLLM parameter construction against the DataRobot LLM Gateway.

Single source of truth for both the chat loop and the recommendation
generator. `Config.resolve_llm_config()` was checked for directly in this
codebase (grep across web/app and core) and does not exist here, so this
builds the params manually — the confirmed-working shape.
"""

from app.config import Config


def build_litellm_params(config: Config) -> dict[str, str]:
    """Params for litellm.completion() against the DataRobot LLM Gateway.

    api_base is the bare endpoint with the trailing /api/v2 stripped and
    nothing appended — appending a path segment (e.g. /llmGateway) 404s;
    the datarobot/ model prefix resolves the real Gateway path internally.
    """
    model = config.llm_default_model
    if not model.startswith("datarobot/"):
        model = f"datarobot/{model}"

    endpoint = config.resolve_datarobot_endpoint().removesuffix("/api/v2")

    return {
        "model": model,
        "api_base": endpoint,
        "api_key": config.resolve_datarobot_api_token(),
    }
