# Copyright 2025 DataRobot, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Recommendation persistence -- the first real database in this build.

Uses `connect_dr_fs` (not plain `aiosqlite.connect`), which syncs the SQLite
file to/from DataRobot's persistent Files/Catalog storage, falling back to a
plain local file when APPLICATION_ID isn't set (local dev). Held as one
long-lived connection via deps.py's lifespan hook -- it pays a full-file sync
round-trip per connect/close, so a fresh connection per request would be
wasteful and would race concurrent writers.

**This is reload-durable within a session, but NOT durable across a redeploy**
-- measured, not assumed: draft + approve, redeploy, re-fetch, and the row is
gone. `connect_dr_fs` downloads the file in `_connect()` and uploads it *only*
in `close()`; there is no sync on commit and no periodic flush. A container
replacement doesn't reliably run that close, so every write since startup is
lost with it. Running a single uvicorn worker (see web/start-app.sh) fixes a
different problem -- divergent per-worker copies of the file -- but does not
change this; tested both ways. A production version needs a managed database
(PostgreSQL), not this.
"""

from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from typing import Any

import aiosqlite
from core.persistent_fs.sqlite_extension import connect_dr_fs

from app.config import Config

_SCHEMA = """
CREATE TABLE IF NOT EXISTS recommendations (
    id TEXT PRIMARY KEY,
    association_id TEXT NOT NULL,
    risk_score REAL NOT NULL,
    risk_tier TEXT NOT NULL,
    drivers_json TEXT NOT NULL,
    narrative TEXT NOT NULL,
    plan_items_json TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    edited_plan_items_json TEXT,
    created_at TEXT NOT NULL,
    actioned_at TEXT,
    actioned_by TEXT
);
"""

_ACTION_TO_STATUS = {"approve": "approved", "edit": "edited", "reject": "rejected"}


async def connect(config: Config) -> aiosqlite.Connection:
    conn = await connect_dr_fs(config.recommendations_db_path)
    await conn.execute(_SCHEMA)
    await conn.commit()
    return conn


def _row_to_dict(row: aiosqlite.Row) -> dict[str, Any]:
    return {
        "id": row["id"],
        "association_id": row["association_id"],
        "risk_score": row["risk_score"],
        "risk_tier": row["risk_tier"],
        "drivers": json.loads(row["drivers_json"]),
        "narrative": row["narrative"],
        "plan_items": json.loads(row["plan_items_json"]),
        "status": row["status"],
        "edited_plan_items": (
            json.loads(row["edited_plan_items_json"])
            if row["edited_plan_items_json"]
            else None
        ),
        "created_at": row["created_at"],
        "actioned_at": row["actioned_at"],
        "actioned_by": row["actioned_by"],
    }


async def insert_recommendation(
    conn: aiosqlite.Connection,
    *,
    association_id: str,
    risk_score: float,
    risk_tier: str,
    drivers: list[dict[str, Any]],
    narrative: str,
    plan_items: list[dict[str, Any]],
) -> dict[str, Any]:
    recommendation_id = str(uuid.uuid4())
    created_at = datetime.now(timezone.utc).isoformat()
    await conn.execute(
        """INSERT INTO recommendations
        (id, association_id, risk_score, risk_tier, drivers_json, narrative,
         plan_items_json, status, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', ?)""",
        (
            recommendation_id,
            association_id,
            risk_score,
            risk_tier,
            json.dumps(drivers),
            narrative,
            json.dumps(plan_items),
            created_at,
        ),
    )
    await conn.commit()
    result = await get_by_id(conn, recommendation_id)
    assert result is not None
    return result


async def get_by_id(conn: aiosqlite.Connection, recommendation_id: str) -> dict[str, Any] | None:
    conn.row_factory = aiosqlite.Row
    async with conn.execute(
        "SELECT * FROM recommendations WHERE id = ?", (recommendation_id,)
    ) as cursor:
        row = await cursor.fetchone()
    return _row_to_dict(row) if row else None


async def get_latest_for_association(
    conn: aiosqlite.Connection, association_id: str
) -> dict[str, Any] | None:
    conn.row_factory = aiosqlite.Row
    async with conn.execute(
        "SELECT * FROM recommendations WHERE association_id = ? "
        "ORDER BY created_at DESC LIMIT 1",
        (association_id,),
    ) as cursor:
        row = await cursor.fetchone()
    return _row_to_dict(row) if row else None


async def apply_action(
    conn: aiosqlite.Connection,
    recommendation_id: str,
    action: str,
    edited_plan_items: list[dict[str, Any]] | None,
) -> dict[str, Any] | None:
    status = _ACTION_TO_STATUS[action]
    actioned_at = datetime.now(timezone.utc).isoformat()
    await conn.execute(
        """UPDATE recommendations
        SET status = ?, edited_plan_items_json = ?, actioned_at = ?
        WHERE id = ?""",
        (
            status,
            json.dumps(edited_plan_items) if edited_plan_items is not None else None,
            actioned_at,
            recommendation_id,
        ),
    )
    await conn.commit()
    return await get_by_id(conn, recommendation_id)
