# Copyright 2025 DataRobot, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""draft_recommendation -- calls the recommendation-drafting Agent
Deployment, a real DataRobot Deployment in this app's own stack (see
infra/infra/agent.py), not the LLM Gateway build_litellm_params() uses.

Calls the deployment's *directAccess* endpoint (AGENT_ENDPOINT, wired by
infra/infra/agent.py -- litellm's openai/ provider appends
/chat/completions to it), authenticated with the platform's own
app-scoped DATAROBOT_API_TOKEN.

Which of the three available call paths is used matters, and the reason
isn't obvious -- confirmed live against this deployment:

  - /deployments/{id}/chat/completions -- works, but does NOT register in
    the deployment's Service Health; serviceStats/predictionUsage stay at
    zero and the calls appear only in OTel Tracing.
  - /genai/agents/fromCustomModel/{customModelId}/chat/ -- registers in
    Service Health, but rejects the app-scoped token (HTTP 401) and takes
    only a personal-API-key-shaped credential, which would tie this
    feature to one person's identity and break sharing the app.
  - /deployments/{id}/directAccess/chat/completions -- registers in
    Service Health *and* is the route the framework itself hands the app
    as AGENT_ENDPOINT. This is the one used here.

/deployments/{id}/predictions is not an option at all: an AgenticWorkflow
custom model doesn't serve it (HTTP 470, "Not Found" from the container).

The agent is asked for strict JSON in its own system prompt
(agent/agent/myagent.py) rather than via LiteLLM's `response_format`
parameter -- passing response_format through a custom `api_base` pointed at
a DataRobot Agent Deployment (as opposed to a raw model endpoint) was never
confirmed to work, so this parses and validates the plain text reply instead.
"""

from __future__ import annotations

import json
import logging
import re
from typing import Any

import litellm

from app.config import Config
from app.discharges import feature_groups
from app.recommendations import rules
from app.telemetry import otel

logger = logging.getLogger(__name__)

_JSON_OBJECT = re.compile(r"\{.*\}", re.DOTALL)


def _driver_phrase(explanation: dict[str, Any]) -> str:
    """One driver, as a clinician-facing label with its real value.

    Two things this fixes. Sending only the feature name produced plan items
    with no numbers in them -- the model could say "review prior utilization"
    but never "2 prior admissions, so follow up within 7 days", because it was
    never told the 2. And sending the raw column name got the raw column name
    quoted straight back into clinician-facing prose ("noting
    number_inpatient = 0"), so the label from feature_groups is used instead.
    """
    label = explanation.get("label") or feature_groups.display_name(explanation["feature"])
    actual = str(explanation.get("actual_value") or "").strip()
    strength = str(explanation.get("qualitative_strength") or "").strip()
    parts = [str(label)]
    if actual:
        parts.append(f"= {actual}")
    if strength:
        parts.append(f"(model impact {strength})")
    return " ".join(parts)


def _build_prompt(
    risk_score: float,
    risk_tier: str,
    grouped_explanations: list[dict[str, Any]],
    required_actions: list[dict[str, str]],
) -> str:
    # The allowed list must include the rule domains, not just the explanation
    # domains. A rule can belong to a domain that isn't among this discharge's
    # top-3 explanations, and listing only the latter contradicted the required
    # items below -- the model resolved that by rewriting driver_cited, so a
    # medication-reconciliation item ended up citing "Discharge Details".
    allowed_domains = [group["group"] for group in grouped_explanations]
    for action in required_actions:
        if action["driver_cited"] not in allowed_domains:
            allowed_domains.append(action["driver_cited"])

    domain_names = ", ".join(f'"{name}"' for name in allowed_domains)
    driver_lines = [
        f'- "{group["group"]}" -- drivers: '
        + ", ".join(_driver_phrase(e) for e in group["explanations"])
        for group in grouped_explanations
    ]
    prompt = (
        f"Risk tier: {risk_tier}\n"
        f"Risk score: {risk_score:.4f}\n"
        f"Top driver domains (each plan item's driver_cited value must be EXACTLY one of "
        f"these domain names, quoted here: {domain_names}):\n" + "\n".join(driver_lines)
    )
    if required_actions:
        # Rule-derived items (rules.py). The agent must carry these through --
        # they already contain the concrete intervals, so it should refine the
        # wording, not replace or drop them.
        #
        # Formatted as a numbered list with the domain on its own line rather
        # than as `- driver_cited "X": text`: that earlier shape taught the
        # model to prefix each item's text with the domain name, so items read
        # "Medical History: Schedule..." under a UI label already saying
        # "Addresses: Medical History".
        required_lines = "\n".join(
            f"{index}. text: {action['text']}\n   driver_cited: {action['driver_cited']}"
            for index, action in enumerate(required_actions, start=1)
        )
        prompt += (
            "\n\nRequired plan items -- these follow from this discharge's own recorded "
            "values. Each must appear in your plan_items with its figures and timeframes "
            "unchanged; reword for tone only, and do not drop or merge any:\n" + required_lines
        )
    return prompt


def _parse_response(content: str) -> dict[str, Any]:
    match = _JSON_OBJECT.search(content)
    if not match:
        raise ValueError(f"Agent response was not JSON: {content[:200]!r}")
    parsed: dict[str, Any] = json.loads(match.group(0))
    return parsed


def _validate_plan_items(
    plan_items: list[dict[str, Any]], valid_domains: set[str]
) -> list[dict[str, Any]]:
    """Server-side guardrail -- never trust the prompt. Drops any plan item
    citing a driver domain that isn't actually among this discharge's real
    explanation domains."""
    validated = []
    for item in plan_items:
        driver_cited = item.get("driver_cited", "")
        if driver_cited in valid_domains:
            validated.append(item)
        else:
            logger.warning("Dropping plan item citing unverified driver: %r", driver_cited)
    return validated


async def draft_recommendation(
    config: Config,
    risk_score: float,
    risk_tier: str,
    grouped_explanations: list[dict[str, Any]],
    features: dict[str, Any] | None = None,
    association_id: str | None = None,
) -> dict[str, Any]:
    """`features` is this discharge's real model inputs, used to derive the
    deterministic required actions in rules.py. Omit it and the agent drafts
    from the explanation domains alone, which is the pre-rules behaviour."""
    required_actions = rules.derive_required_actions(features) if features else []
    prompt = _build_prompt(risk_score, risk_tier, grouped_explanations, required_actions)
    # A rule cites the domain it belongs to, which is not always among this
    # discharge's top-3 explanation domains -- accept both, or validation would
    # silently drop the very items the rules require.
    valid_domains = {group["group"] for group in grouped_explanations}
    valid_domains |= {action["driver_cited"] for action in required_actions}

    # No /chat/completions suffix here -- litellm's openai/ provider appends the
    # OpenAI-style path itself; a full URL 404s (confirmed live against this deployment).
    api_base = config.agent_endpoint

    with otel.span(
        "generate_recommendation", **{"gen_ai.prompt": prompt}
    ) as span:
        # datarobot_association_id is the platform's own field for joining a
        # call to the prediction row behind it. Worth sending regardless of
        # feedback: it is what makes this trace joinable to the score.
        extra_body: dict[str, Any] = {}
        if association_id:
            extra_body["datarobot_association_id"] = association_id
        response = await litellm.acompletion(
            model="openai/agent-deployment",
            api_base=api_base,
            api_key=config.resolve_datarobot_api_token(),
            messages=[{"role": "user", "content": prompt}],
            **({"extra_body": extra_body} if extra_body else {}),
        )
        content = response.choices[0].message.content or ""
        span.set_attribute("gen_ai.completion", content)

    parsed = _parse_response(content)
    narrative = str(parsed.get("narrative", ""))
    plan_items = _validate_plan_items(parsed.get("plan_items", []), valid_domains)

    return {"narrative": narrative, "plan_items": plan_items}
