# Copyright 2025 DataRobot, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Deterministic discharge-planning rules, evaluated before the agent runs.

These come from the original design (see
handoffs/healthcare_readmission_handoff/agent_specs/risk_aware_discharge_agent_spec.md,
"Template Logic Examples"). They exist because an LLM asked only for "3-5 plan
items" produces items with no numbers in them: every recommendation reads the
same regardless of whether the patient had two prior admissions or twelve
medications. A rule fires on a real feature value and states a concrete
interval, and the agent is then asked to incorporate it rather than invent it.

Each rule names the clinical domain it belongs to, matching the group names in
config/feature_group_mapping.json, so a rule-derived plan item survives
`generator._validate_plan_items`.
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)

# Feature values at or above which a rule fires. Kept as named constants so the
# thresholds are visible and adjustable in one place, not buried in branches.
PRIOR_INPATIENT_THRESHOLD = 2
MEDICATION_COUNT_THRESHOLD = 10

# Dispositions that indicate ongoing clinical support is already expected.
_SUPPORTED_DISCHARGE_MARKERS = ("SNF", "home health", "ICF", "nursing facility")


def _as_int(value: Any) -> int | None:
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return None


def derive_required_actions(features: dict[str, Any]) -> list[dict[str, str]]:
    """Returns the plan items this discharge's own feature values require.

    Ordered most- to least-specific so the prompt lists the strongest first.
    An empty list is a valid result -- it means no threshold was crossed, and
    the agent then drafts from the explanation domains alone.
    """
    actions: list[dict[str, str]] = []

    prior_inpatient = _as_int(features.get("number_inpatient"))
    if prior_inpatient is not None and prior_inpatient >= PRIOR_INPATIENT_THRESHOLD:
        actions.append(
            {
                "driver_cited": "Medical History",
                "text": (
                    f"Schedule an intensive outpatient appointment within 7 days of "
                    f"discharge. {prior_inpatient} prior inpatient admissions indicate "
                    f"chronic instability, so an early clinical touchpoint matters most here."
                ),
            }
        )

    medications = _as_int(features.get("num_medications"))
    if medications is not None and medications >= MEDICATION_COUNT_THRESHOLD:
        actions.append(
            {
                "driver_cited": "Clinical Metrics",
                "text": (
                    f"Arrange a pharmacist medication reconciliation within 48 hours. "
                    f"The patient is on {medications} active medications, which carries a "
                    f"real risk of adherence problems or interactions."
                ),
            }
        )

    disposition = str(features.get("discharge_disposition_id") or "")
    if any(marker.lower() in disposition.lower() for marker in _SUPPORTED_DISCHARGE_MARKERS):
        actions.append(
            {
                "driver_cited": "Discharge Details",
                "text": (
                    "Confirm the receiving facility or home health agency has the discharge "
                    "summary and a clear care plan, with daily monitoring for the first 14 days."
                ),
            }
        )

    if str(features.get("admission_type_id") or "").strip().lower() == "emergency":
        actions.append(
            {
                "driver_cited": "Discharge Details",
                "text": (
                    "Review a warning-signs education sheet with the patient and family before "
                    "discharge. This was an emergency admission, so symptom recognition is the "
                    "difference between a clinic call and another admission."
                ),
            }
        )

    logger.info(
        "Derived %d required action(s) from feature values (prior_inpatient=%s, medications=%s)",
        len(actions),
        prior_inpatient,
        medications,
    )
    return actions
