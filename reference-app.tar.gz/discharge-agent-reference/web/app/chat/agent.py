# Copyright 2025 DataRobot, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""The chat loop: a plain LiteLLM function-calling loop, not an agent
framework. One tool call at most per question -- the model never has to
orchestrate a multi-step plan itself.
"""

from __future__ import annotations

import json
import logging

import litellm

from app.chat.tools import dispatch_tool, tool_schemas
from app.config import Config
from app.llm_config import build_litellm_params
from app.telemetry import otel

logger = logging.getLogger(__name__)

SYSTEM_PROMPT = """You are a care-coordination analyst assistant for a high-risk \
diabetes discharge cohort (39.65% 30-day readmission baseline).

- Speak in plain, clinician-friendly language -- no ML jargon.
- Always frame readmission rates relative to the 39.65% cohort baseline.
- Answer only from tool results -- never recall or estimate a number yourself.
- You can score and explain one specific discharge's readmission risk, and \
simulate a hypothetical change to it -- but only when the user gives a real \
association_id (e.g. from the discharge queue). Never invent an association_id.
- A what-if result is always a simulation, never an official prediction -- say \
so explicitly whenever you report one.
- Decline clearly, rather than guessing, when asked something this data can't \
answer: looking a patient up by name, anything about the real future beyond \
the as-of date, or a cohort-wide prediction/what-if (only one discharge at a \
time is ever scored)."""


def _json_safe(value: object) -> str:
    """Serialize a tool result for the model, tolerating numpy/pandas scalar
    types that occasionally slip through pandas aggregations."""
    return json.dumps(value, default=str)


async def chat(messages: list[dict[str, str]], config: Config) -> str:
    """One turn: send the conversation with the registered tool schemas,
    execute at most one tool call if the model asks for one, return the
    model's final reply text.
    """
    params = build_litellm_params(config)
    full_messages: list[dict[str, object]] = [
        {"role": "system", "content": SYSTEM_PROMPT},
        *messages,
    ]
    last_user_message = next(
        (m["content"] for m in reversed(messages) if m.get("role") == "user"), ""
    )

    with otel.span(
        "llm_call",
        **{"gen_ai.request.model": params["model"], "gen_ai.prompt": last_user_message},
    ) as span:
        response = await litellm.acompletion(
            **params, messages=full_messages, tools=tool_schemas()
        )
        response_message = response.choices[0].message
        tool_calls = getattr(response_message, "tool_calls", None)

        if not tool_calls:
            content = response_message.content or ""
            span.set_attribute("gen_ai.completion", content)
            return content

    # At most one tool call is handled -- the model never gets to chain more.
    tool_call = tool_calls[0]
    tool_name = tool_call.function.name
    tool_args = json.loads(tool_call.function.arguments or "{}")

    with otel.span("tool_execution", tool_name=tool_name) as tool_span:
        try:
            result = await dispatch_tool(tool_name, tool_args, config)
        except Exception as exc:  # noqa: BLE001 -- surfaced to the model as a tool error, not a 500
            logger.exception("Tool %s failed", tool_name)
            result = {"error": str(exc)}
        tool_span.set_attribute("tool_result_size", len(_json_safe(result)))

    full_messages.append(
        {
            "role": "assistant",
            "content": response_message.content or "",
            "tool_calls": [
                {
                    "id": tool_call.id,
                    "type": "function",
                    "function": {
                        "name": tool_name,
                        "arguments": tool_call.function.arguments,
                    },
                }
            ],
        }
    )
    full_messages.append(
        {
            "role": "tool",
            "tool_call_id": tool_call.id,
            "content": _json_safe(result),
        }
    )

    with otel.span(
        "llm_call_with_tool_result", **{"gen_ai.request.model": params["model"]}
    ) as span2:
        final_response = await litellm.acompletion(**params, messages=full_messages)
        final_content = final_response.choices[0].message.content or ""
        span2.set_attribute("gen_ai.completion", final_content)

    return final_content
