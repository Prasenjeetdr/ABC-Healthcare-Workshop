# Copyright 2025 DataRobot, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Phase 3's two chat tools: score_and_explain_patient and what_if_patient.
Both take an association_id, never raw feature values, through chat --
identifiers are the only thing that ever reaches the model here, the same
guardrail Phase 2 established for query_cohort_history."""

from __future__ import annotations

from typing import Any

from app.chat.tools import register_tool
from app.config import Config
from app.discharges import data as discharges_data
from app.discharges import feature_groups, scoring


async def score_and_explain_patient(config: Config, association_id: str) -> dict[str, Any]:
    try:
        features = await discharges_data.get_patient_features(config, association_id)
    except KeyError as exc:
        return {"error": str(exc)}
    result = await scoring.score_and_explain(config, features)
    result["grouped_explanations"] = feature_groups.group_explanations(result["explanations"])
    return result


SCORE_AND_EXPLAIN_PATIENT_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "score_and_explain_patient",
        "description": (
            "Score one specific discharge's 30-day readmission risk and explain the "
            "prediction, by its association_id. Only use this when the user references "
            "a specific discharge by its association_id -- never invent one, and never "
            "answer a risk question without a real association_id to score."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "association_id": {
                    "type": "string",
                    "description": "The discharge's association_id, from the discharge queue.",
                },
            },
            "required": ["association_id"],
        },
    },
}

register_tool(
    "score_and_explain_patient", SCORE_AND_EXPLAIN_PATIENT_SCHEMA, score_and_explain_patient
)


async def what_if_patient(
    config: Config, association_id: str, overrides: dict[str, Any]
) -> dict[str, Any]:
    try:
        features = await discharges_data.get_patient_features(config, association_id)
    except KeyError as exc:
        return {"error": str(exc)}
    return await scoring.what_if(config, features, overrides)


WHAT_IF_PATIENT_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "what_if_patient",
        "description": (
            "Simulate how one specific discharge's readmission risk would change if "
            "given feature values were different. Always a hypothetical, never an "
            "official prediction -- state that clearly in your answer."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "association_id": {
                    "type": "string",
                    "description": "The discharge's association_id.",
                },
                "overrides": {
                    "type": "object",
                    "description": (
                        "Feature name to hypothetical value, e.g. "
                        '{"time_in_hospital": 10}.'
                    ),
                },
            },
            "required": ["association_id", "overrides"],
        },
    },
}

register_tool("what_if_patient", WHAT_IF_PATIENT_SCHEMA, what_if_patient)
