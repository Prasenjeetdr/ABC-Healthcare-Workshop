# Copyright 2025 DataRobot, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""The chat's tool registry.

Built as a dict[str, ToolSpec] from the start (Phase 2 only registers one
tool) because later phases add more tools into this same registry -- a
single-tool special case here would force a refactor once they land.
"""

from __future__ import annotations

import inspect
import logging
from dataclasses import dataclass
from typing import Any, Awaitable, Callable

import pandas as pd

from app.cohorts import data as cohorts_data
from app.config import Config

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class ToolSpec:
    """One chat-callable tool: its LiteLLM/OpenAI schema and its handler.
    A handler may be sync (Phase 2's tool) or async (Phase 3's, which call
    Global MCP) -- dispatch_tool handles both uniformly."""

    schema: dict[str, Any]
    handler: Callable[..., Any]


TOOLS: dict[str, ToolSpec] = {}


def register_tool(
    name: str,
    schema: dict[str, Any],
    handler: Callable[..., Any],
) -> None:
    TOOLS[name] = ToolSpec(schema=schema, handler=handler)


def tool_schemas() -> list[dict[str, Any]]:
    """The `tools=[...]` list for litellm.completion(), in registration order."""
    return [spec.schema for spec in TOOLS.values()]


async def dispatch_tool(name: str, arguments: dict[str, Any], config: Config) -> Any:
    """Call a registered tool's handler by name, passing config plus the
    model-supplied arguments. Awaits the result if the handler is async."""
    if name not in TOOLS:
        return {"error": f"Unknown tool: {name}"}
    result: Any | Awaitable[Any] = TOOLS[name].handler(config=config, **arguments)
    if inspect.isawaitable(result):
        return await result
    return result


# --- query_cohort_history ---------------------------------------------------


def query_cohort_history(
    config: Config,
    query_type: str,
    dimension: str | None = None,
    start_date: str | None = None,
    end_date: str | None = None,
    race: list[str] | None = None,
    gender: list[str] | None = None,
    age: list[str] | None = None,
    discharge_disposition_id: list[str] | None = None,
    admission_type_id: list[str] | None = None,
) -> dict[str, Any] | list[dict[str, Any]]:
    """Answers the chat's historical-trend questions.

    Calls the *same* Phase 1 data-layer functions the REST endpoints use --
    never duplicates the aggregation logic, so chat can never disagree with
    the dashboard. Never returns a raw patient row; only the same aggregates
    the dashboard's own endpoints already return.
    """
    filters = cohorts_data.HistoryFilters(
        start_date=pd.Timestamp(start_date) if start_date else None,
        end_date=pd.Timestamp(end_date) if end_date else None,
        race=tuple(race) if race else None,
        gender=tuple(gender) if gender else None,
        age=tuple(age) if age else None,
        discharge_disposition_id=(
            tuple(discharge_disposition_id) if discharge_disposition_id else None
        ),
        admission_type_id=tuple(admission_type_id) if admission_type_id else None,
    )
    df = cohorts_data.apply_filters(cohorts_data.get_history_dataframe(config), filters)

    if query_type == "summary":
        return cohorts_data.summarize(df)
    if query_type == "trend":
        return cohorts_data.monthly_trend(df)
    if query_type == "segment":
        if not dimension:
            return {"error": "dimension is required when query_type is 'segment'"}
        if dimension not in cohorts_data.SEGMENT_DIMENSIONS:
            return {
                "error": (
                    f"Unknown dimension: {dimension}. "
                    f"Valid dimensions: {', '.join(cohorts_data.SEGMENT_DIMENSIONS)}"
                )
            }
        return cohorts_data.segment_breakdown(df, dimension)
    return {"error": f"Unknown query_type: {query_type}"}


QUERY_COHORT_HISTORY_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "query_cohort_history",
        "description": (
            "Query historical readmission data for the high-risk diabetes cohort "
            "(39.65% baseline 30-day readmission rate). Use for any question about "
            "past readmission rates, trends over time, or breakdowns by demographic "
            "or clinical segment. Never answers with predictions or individual "
            "patient information -- historical, aggregate data only."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "query_type": {
                    "type": "string",
                    "enum": ["summary", "trend", "segment"],
                    "description": (
                        "'summary' for overall cohort stats, 'trend' for the "
                        "monthly readmission rate over time, 'segment' for a "
                        "breakdown by one demographic/clinical dimension."
                    ),
                },
                "dimension": {
                    "type": "string",
                    "enum": list(cohorts_data.SEGMENT_DIMENSIONS),
                    "description": "Required when query_type is 'segment'.",
                },
                "start_date": {
                    "type": "string",
                    "description": "Filter to admissions on/after this date (YYYY-MM-DD).",
                },
                "end_date": {
                    "type": "string",
                    "description": "Filter to admissions on/before this date (YYYY-MM-DD).",
                },
                "race": {"type": "array", "items": {"type": "string"}},
                "gender": {"type": "array", "items": {"type": "string"}},
                "age": {"type": "array", "items": {"type": "string"}},
                "discharge_disposition_id": {"type": "array", "items": {"type": "string"}},
                "admission_type_id": {"type": "array", "items": {"type": "string"}},
            },
            "required": ["query_type"],
        },
    },
}

register_tool("query_cohort_history", QUERY_COHORT_HISTORY_SCHEMA, query_cohort_history)

# Phase 3 registers two more tools into this same registry -- imported last,
# after register_tool exists, since discharge_tools imports it back from here.
from app.chat import discharge_tools  # noqa: E402, F401
