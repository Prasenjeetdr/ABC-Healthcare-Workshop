# Copyright 2025 DataRobot, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Client for DataRobot's Global MCP -- an org-wide service DataRobot
auto-deploys to every instance; nothing is deployed by this app for it.

Unlike llm_config.py's Gateway `api_base` (which strips the trailing
/api/v2), Global MCP's URL keeps it: `{DATAROBOT_ENDPOINT}/genai/globalmcp/mcp`.

Authenticated with a *dedicated* personal-API-key credential
(`config.global_mcp_api_token`), not `resolve_datarobot_api_token()`.
Confirmed live: a deployed Custom Application's `DATAROBOT_API_TOKEN` is the
platform's own auto-injected, app-scoped credential -- it's never explicitly
wired by this project, since DataRobot injects it into every Custom
Application automatically. That token works fine for `dr.Client` calls and
the LLM Gateway, but Global MCP rejects it with a plain-text
`{"message": "Invalid Authorization header"}` (HTTP 401) -- it expects a
personal-API-key-shaped credential, which the app-scoped one isn't. See
`infra/infra/web.py`'s `GLOBAL_MCP_API_TOKEN` credential for how this gets
wired as its own Pulumi runtime parameter, same pattern as `SESSION_SECRET_KEY`.
"""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from typing import Any, AsyncGenerator

from mcp import ClientSession
from mcp.client.streamable_http import httpx2, streamable_http_client
from mcp.shared.exceptions import MCPError

from app.config import Config

logger = logging.getLogger(__name__)


async def _log_error_responses(response: Any) -> None:
    """httpx response hook -- the mcp SDK swallows the real HTTP status/body
    of a failed request behind a generic MCPError(-32603), so this is the
    only place a future auth/config regression would actually be visible."""
    if response.status_code >= 400:
        await response.aread()
        logger.error(
            "Global MCP HTTP %s %s -- headers=%r body=%r",
            response.status_code,
            response.request.url,
            dict(response.headers),
            response.text[:2000],
        )


@asynccontextmanager
async def _session(config: Config) -> AsyncGenerator[ClientSession, None]:
    url = f"{config.resolve_datarobot_endpoint()}/genai/globalmcp/mcp"
    # global_mcp_api_token is required for this to work once deployed (see
    # module docstring); resolve_datarobot_api_token() is a fallback only for
    # the unlikely case the dedicated credential wasn't configured.
    token = config.global_mcp_api_token or config.resolve_datarobot_api_token() or ""
    http_client = httpx2.AsyncClient(
        headers={
            "Authorization": f"Bearer {token}",
            "x-datarobot-api-token": token,
        },
        timeout=60.0,
        event_hooks={"response": [_log_error_responses]},
    )
    async with streamable_http_client(url, http_client=http_client) as (
        read_stream,
        write_stream,
    ):
        async with ClientSession(read_stream, write_stream) as session:
            try:
                await session.initialize()
            except MCPError as exc:
                logger.error(
                    "Global MCP initialize failed: code=%r message=%r data=%r url=%r",
                    exc.code,
                    exc.message,
                    exc.data,
                    url,
                )
                raise
            yield session


async def call_tool(config: Config, name: str, arguments: dict[str, Any]) -> Any:
    """Call one Global MCP tool. Opens and closes its own session -- these
    calls are infrequent enough (one score, one batch submit, a handful of
    polls) that session-per-call is simpler than pooling."""
    async with _session(config) as session:
        result = await session.call_tool(name, arguments)
        return result.structured_content
