# Copyright 2025 DataRobot, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import os

from datarobot.core.config import DataRobotAppFrameworkBaseSettings
from pydantic import ValidationInfo, field_validator

from app.telemetry.enums import FormatType, LogLevel


class Config(DataRobotAppFrameworkBaseSettings):
    session_secret_key: str
    session_max_age: int = 14 * 24 * 60 * 60  # 14 days, in seconds
    session_https_only: bool = True
    session_cookie_name: str = "sess"  # Can be overridden for different apps

    log_level: LogLevel = LogLevel.INFO
    log_format: FormatType = "json"

    datarobot_endpoint: str = ""
    datarobot_api_token: str = ""

    # A dedicated personal-API-key credential for Global MCP calls only -- required.
    # The platform's own auto-injected DATAROBOT_API_TOKEN (an app-scoped credential,
    # not a personal key) works fine for dr.Client/LLM Gateway calls but Global MCP
    # rejects it with "Invalid Authorization header" (confirmed live). See
    # app/mcp_client.py's module docstring for the full story.
    #
    # Deliberately scoped to Global MCP alone: a personal key ties whatever uses it
    # to one person's identity, which breaks sharing the app with other users, so
    # nothing else should depend on it. See app/recommendations/generator.py.
    global_mcp_api_token: str = ""

    # AI Catalog dataset IDs backing the cohort dashboard and prediction pool.
    discharge_training_dataset_id: str = ""
    discharge_actuals_dataset_id: str = ""
    discharge_predictions_dataset_id: str = ""

    # Readmission-risk deployment (used starting Phase 3).
    readmission_deployment_id: str = ""

    # LLM Gateway (used starting Phase 2's chat, and Phase 4's recommendation drafting).
    llm_default_model: str = ""
    use_datarobot_llm_gateway: bool = True

    # "Today's" discharge date for the predictions pool — a chosen, fixed slice, not
    # the real current date (see full_stack_spec.md's Data sources section). Empty
    # means "compute a default from the pool's own real date range at startup."
    discharge_as_of_date: str = ""

    # Recommendation drafting persistence (Phase 4).
    recommendations_db_path: str = "recommendations.db"

    # Recommendation-drafting Agent Deployment (Phase 4) — its directAccess base
    # URL, wired automatically as a Pulumi runtime parameter (AGENT_ENDPOINT) by
    # infra/infra/agent.py, not set by hand in .env. Calls through it register in
    # the deployment's Service Health, unlike the /deployments/{id}/chat/completions
    # shortcut -- see app/recommendations/generator.py's module docstring.
    #
    agent_endpoint: str = ""

    # Declared as of the feedback add-on: custom metrics are addressed by
    # deployment id, which agent_endpoint embeds but does not expose. infra has
    # always injected this runtime parameter; it simply had no reader before.
    agent_deployment_id: str = ""

    otel_entity_id: str = ""
    otel_exporter_otlp_endpoint: str = ""
    otel_exporter_otlp_headers: str = ""
    otel_sdk_disabled: bool = False
    profiling_enabled: bool = False

    @field_validator("otel_exporter_otlp_headers", mode="before")
    @classmethod
    def _assemble_otel_headers(cls, v: object, info: ValidationInfo) -> object:
        if v:
            return v
        entity_id = (info.data or {}).get("otel_entity_id", "")
        api_token = (info.data or {}).get("datarobot_api_token", "") or os.environ.get(
            "DATAROBOT_API_TOKEN", ""
        )
        if entity_id and api_token:
            return f"x-datarobot-entity-id={entity_id},x-datarobot-api-key={api_token}"
        return v

    @field_validator("otel_sdk_disabled", mode="before")
    @classmethod
    def _coerce_empty_string(cls, v: object) -> object:
        return False if v == "" else v
