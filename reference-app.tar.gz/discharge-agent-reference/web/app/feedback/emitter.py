# Copyright 2025 DataRobot, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Getting a human's verdict off this box and onto the platform.

Two channels, because they answer different questions:

* **A span**, always. Lands in App tracing next to the request the feedback is
  about, and carries the free text. Answers "what did the clinician say about
  this specific draft".
* **A deployment custom metric**, when the deployment has been prepared for it.
  Answers "what is the down-vote rate this week", which a span tree cannot.

The metric is a *numeric* counter (`human_feedback_up` / `human_feedback_down`),
because DataRobot's custom metrics only accept numbers -- the sentiment becomes
which metric is incremented, not a value.

Deliberately best-effort: `record_feedback` in the router writes locally first
and only then calls this. A clinician's click must not fail because a
governance side-channel is misconfigured, so every failure here is logged and
swallowed, and `emitted_at` simply stays NULL. `GET /api/v1/feedback/status`
reports which channels are actually live so the UI can say so rather than
implying a metric exists.
"""

from __future__ import annotations

import json
import logging
from typing import Any

import httpx

from app.config import Config
from app.telemetry.otel import otel

logger = logging.getLogger(__name__)

# The metric names the deployment must already define. DataRobot rejects a
# submission whose name it does not know, so these are fixed, not derived.
METRIC_UP = "human_feedback_up"
METRIC_DOWN = "human_feedback_down"

_TIMEOUT = httpx.Timeout(10.0)


def emit_span(record: dict[str, Any]) -> None:
    """Always safe to call.

    Attribute names here are chosen so the verdict is readable from the tracing
    *table*, not only after expanding a span. DataRobot's table maps specific
    attributes to columns:

    * `tool_name` (underscore -- `tool.name` is not read) feeds the Tools
      column, so the sentiment is baked into it: a reviewer scanning the list
      sees `human_feedback_down` without opening anything.
    * `gen_ai.completion` feeds the Completion column, and carries the verdict
      in words so a thumbs-up with no comment is still legible.
    * `gen_ai.prompt` feeds the Prompt column and carries the comment, so the
      row reads "what they said" -> "what they thought".

    The `feedback.*` attributes stay as the precise, machine-readable copy.
    """
    sentiment = record["sentiment"]
    attributes: dict[str, Any] = {
        # The binary, in the column the table already shows.
        "tool_name": f"human_feedback_{sentiment}",
        "gen_ai.completion": "useful" if sentiment == "up" else "not useful",
        "feedback.sentiment": sentiment,
        "feedback.subject_type": record["subject_type"],
        "feedback.subject_id": record["subject_id"],
        # Documented as a JSON string; gives the whole record in one place.
        "tool.parameters": json.dumps(
            {
                "sentiment": sentiment,
                "subject_type": record["subject_type"],
                "subject_id": record["subject_id"],
                "association_id": record.get("association_id"),
            }
        ),
    }
    if record.get("association_id"):
        attributes["association_id"] = record["association_id"]
    with otel.span("human_feedback", **attributes) as span:
        # The comment is clinician-authored prose about the app's output, so it
        # is safe to carry. Never copy patient fields into it.
        if record.get("comment"):
            span.set_attribute("gen_ai.prompt", record["comment"])


async def _custom_metric_ids(config: Config) -> dict[str, str]:
    """Map our two metric names to their ids on the agent deployment.

    Returns {} when the deployment defines neither, which is the normal state
    until somebody creates them -- not an error.
    """
    if not config.agent_deployment_id:
        return {}
    url = (
        f"{config.datarobot_endpoint.rstrip('/')}"
        f"/deployments/{config.agent_deployment_id}/customMetrics/"
    )
    headers = {"Authorization": f"Bearer {config.datarobot_api_token}"}
    async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
        # limit caps at 50; 100 is rejected with HTTP 400.
        response = await client.get(url, headers=headers, params={"limit": 50})
    response.raise_for_status()
    wanted = {METRIC_UP, METRIC_DOWN}
    return {
        item["name"]: item["id"]
        for item in response.json().get("data", [])
        if item.get("name") in wanted
    }


async def emit_metric(config: Config, record: dict[str, Any]) -> bool:
    """Submit 1 against the metric matching the sentiment. False when the
    channel isn't available, which the caller treats as "not emitted" rather
    than as a failure to show the user."""
    try:
        ids = await _custom_metric_ids(config)
    except Exception:
        logger.warning(
            "Could not list custom metrics on the agent deployment", exc_info=True
        )
        return False

    name = METRIC_UP if record["sentiment"] == "up" else METRIC_DOWN
    metric_id = ids.get(name)
    if metric_id is None:
        logger.info(
            "Custom metric %r is not defined on the agent deployment; "
            "feedback recorded as a span only",
            name,
        )
        return False

    url = (
        f"{config.datarobot_endpoint.rstrip('/')}"
        f"/deployments/{config.agent_deployment_id}"
        f"/customMetrics/{metric_id}/fromJSON/"
    )
    bucket: dict[str, Any] = {
        "value": 1,
        "sampleSize": 1,
        "timestamp": record["created_at"],
        # Read-only, 128 chars max -- enough to say which surface was judged.
        "metadata": record["subject_type"],
    }
    # Deliberately NOT sending associationId. The schema describes it as
    # "identifies prediction row corresponding to value", but this is an
    # AgenticWorkflow deployment and the API answers
    # "Predictions results are not available for this deployment type" -- there
    # are no rows to point at, so an association id here resolves to nothing and
    # shows up as a blank row lookup in the UI. All feedback is treated as
    # interaction with the app, counted on this one deployment. The id is still
    # on the span, where it correlates the verdict with the app's own trace.
    # dryRun is a required field, not an optional flag -- omitting it is a 422.
    payload: dict[str, Any] = {"buckets": [bucket], "dryRun": False}

    try:
        async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
            response = await client.post(
                url,
                headers={"Authorization": f"Bearer {config.datarobot_api_token}"},
                json=payload,
            )
        response.raise_for_status()
    except Exception:
        logger.warning("Custom metric submission failed for %r", name, exc_info=True)
        return False
    return True


async def channel_status(config: Config) -> dict[str, Any]:
    """What the UI is allowed to claim. Tracing is always on; the metric
    depends on whether anyone defined it."""
    metrics: dict[str, bool] = {}
    error: str | None = None
    try:
        ids = await _custom_metric_ids(config)
        metrics = {METRIC_UP: METRIC_UP in ids, METRIC_DOWN: METRIC_DOWN in ids}
    except Exception as exc:  # noqa: BLE001 -- reported, not raised
        error = type(exc).__name__
    return {
        "tracing": True,
        "metrics_available": bool(metrics) and all(metrics.values()),
        "metrics": metrics,
        "agent_deployment_id": config.agent_deployment_id or None,
        "error": error,
    }
