# Copyright 2025 DataRobot, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Feedback persistence.

Deliberately shares the recommendations connection rather than opening a
second one: `connect_dr_fs` pays a full-file sync per connect/close, and two
connections to two files would double that cost and give us two things to
lose on a container replacement instead of one. `ensure_schema` is called from
deps.py's lifespan against the already-open connection.

The same durability caveat as `recommendations/db.py` applies -- reload-durable
within a session, gone after a redeploy. That is *why* `emitted_at` exists: the
platform-side signal is the durable record, and the local row is the receipt
for it.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Any, Literal

import aiosqlite

SubjectType = Literal["risk_score", "recommendation", "chat_answer"]
Sentiment = Literal["up", "down"]

_SCHEMA = """
CREATE TABLE IF NOT EXISTS feedback (
    id TEXT PRIMARY KEY,
    subject_type TEXT NOT NULL,
    subject_id TEXT NOT NULL,
    association_id TEXT,
    sentiment TEXT NOT NULL,
    comment TEXT,
    created_at TEXT NOT NULL,
    emitted_at TEXT
);
"""

# One opinion per subject: a second submission replaces the first rather than
# accumulating, so a chart of down-votes counts subjects and not clicks.
_INDEX = """
CREATE UNIQUE INDEX IF NOT EXISTS feedback_subject
    ON feedback (subject_type, subject_id);
"""


async def ensure_schema(conn: aiosqlite.Connection) -> None:
    await conn.execute(_SCHEMA)
    await conn.execute(_INDEX)
    await conn.commit()


def _row_to_dict(row: aiosqlite.Row) -> dict[str, Any]:
    return {
        "id": row["id"],
        "subject_type": row["subject_type"],
        "subject_id": row["subject_id"],
        "association_id": row["association_id"],
        "sentiment": row["sentiment"],
        "comment": row["comment"],
        "created_at": row["created_at"],
        # Surfaced so the UI can be honest about where the signal got to.
        "emitted": row["emitted_at"] is not None,
    }


async def upsert(
    conn: aiosqlite.Connection,
    *,
    subject_type: str,
    subject_id: str,
    association_id: str | None,
    sentiment: str,
    comment: str | None,
) -> dict[str, Any]:
    """Record the click. Never fails on the platform's behalf -- emitting is a
    separate step, and `emitted_at` stays NULL until it succeeds."""
    conn.row_factory = aiosqlite.Row
    now = datetime.now(timezone.utc).isoformat()
    await conn.execute(
        """
        INSERT INTO feedback
            (id, subject_type, subject_id, association_id, sentiment, comment, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT (subject_type, subject_id) DO UPDATE SET
            sentiment = excluded.sentiment,
            comment = excluded.comment,
            created_at = excluded.created_at,
            emitted_at = NULL
        """,
        (
            str(uuid.uuid4()),
            subject_type,
            subject_id,
            association_id,
            sentiment,
            comment,
            now,
        ),
    )
    await conn.commit()
    result = await get(conn, subject_type=subject_type, subject_id=subject_id)
    assert result is not None  # just written
    return result


async def mark_emitted(conn: aiosqlite.Connection, feedback_id: str) -> None:
    await conn.execute(
        "UPDATE feedback SET emitted_at = ? WHERE id = ?",
        (datetime.now(timezone.utc).isoformat(), feedback_id),
    )
    await conn.commit()


async def get(
    conn: aiosqlite.Connection, *, subject_type: str, subject_id: str
) -> dict[str, Any] | None:
    conn.row_factory = aiosqlite.Row
    async with conn.execute(
        "SELECT * FROM feedback WHERE subject_type = ? AND subject_id = ?",
        (subject_type, subject_id),
    ) as cursor:
        row = await cursor.fetchone()
    return _row_to_dict(row) if row else None


async def counts(conn: aiosqlite.Connection) -> dict[str, int]:
    """Local tally, for the app's own honesty about what it has collected.
    The platform's metric is the reviewable one; this is not a substitute."""
    conn.row_factory = aiosqlite.Row
    async with conn.execute(
        "SELECT sentiment, COUNT(*) AS n FROM feedback GROUP BY sentiment"
    ) as cursor:
        rows = await cursor.fetchall()
    tally = {"up": 0, "down": 0}
    for row in rows:
        if row["sentiment"] in tally:
            tally[row["sentiment"]] = int(row["n"])
    return tally
