# Copyright 2025 DataRobot, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Loads the forward-looking predictions pool (Phase 3) and manages the
cached batch-scored risk tiers backing the "Discharges for Today" queue.

`DISCHARGE_PREDICTIONS_DATASET_ID` is a real, separate features-only pool --
no `readmitted` target, its own `discharge_date` range -- not part of
Phase 1's history dataframe.
"""

from __future__ import annotations

import asyncio
import csv
import io
import logging
import threading
import time
from datetime import date
from typing import Any

import datarobot as dr
import pandas as pd

from app.config import Config
from app.discharges import feature_groups, scoring
from app.mcp_client import call_tool

logger = logging.getLogger(__name__)

_POOL_CACHE_TTL_SECONDS = 15 * 60
_pool_lock = threading.Lock()
_cached_pool: pd.DataFrame | None = None
_cached_pool_at: float = 0.0

# The batch job takes roughly a minute for the full pool -- cache the
# result and refresh on an hourly interval, not per request.
_BATCH_CACHE_TTL_SECONDS = 60 * 60
_batch_lock = asyncio.Lock()
_cached_scores: dict[str, dict[str, Any]] | None = None
_cached_scores_at: float = 0.0


def _get_client(config: Config) -> dr.Client:
    return dr.Client(
        token=config.resolve_datarobot_api_token(),
        endpoint=config.resolve_datarobot_endpoint(),
    )


def _load_pool_dataframe(config: Config) -> pd.DataFrame:
    _get_client(config)
    dataset = dr.Dataset.get(config.discharge_predictions_dataset_id)
    df = dataset.get_as_dataframe()
    df["admission_date"] = pd.to_datetime(df["admission_date"])
    df["discharge_date"] = pd.to_datetime(df["discharge_date"])
    return df


def get_pool_dataframe(config: Config, force_refresh: bool = False) -> pd.DataFrame:
    global _cached_pool, _cached_pool_at

    with _pool_lock:
        is_stale = (time.monotonic() - _cached_pool_at) > _POOL_CACHE_TTL_SECONDS
        if _cached_pool is None or is_stale or force_refresh:
            logger.info("Refreshing predictions pool from AI Catalog")
            _cached_pool = _load_pool_dataframe(config)
            _cached_pool_at = time.monotonic()
        return _cached_pool


def resolve_as_of_date(config: Config) -> str:
    """The predictions pool's "as of" date -- always a real date from the pool,
    never `pd.Timestamp.now()` itself, since the pool has no live feed.

    With no explicit config value, this picks the pool date closest to the real
    current date, clamping to an endpoint when today falls outside the pool's
    range. It used to default to the pool's *earliest* date, which is the
    emptiest day in this pool (3 rows against a median of 31), so the queue
    showed a handful of same-tier patients and the MEDIUM/LOW recommendation
    paths never appeared in the app at all.

    Ties (today exactly between two pool dates) resolve to the earlier one,
    because the candidate list is sorted -- so the result is stable for a given
    day and dataset. Set DISCHARGE_AS_OF_DATE to pin it for a scripted demo.
    """
    if config.discharge_as_of_date:
        return config.discharge_as_of_date
    df = get_pool_dataframe(config)
    pool_dates: list[date] = sorted(df["discharge_date"].dt.date.unique())
    today = date.today()
    nearest: date = min(pool_dates, key=lambda pool_date: abs(pool_date - today))
    return nearest.isoformat()


def get_patient_row(config: Config, association_id: str) -> pd.Series:
    df = get_pool_dataframe(config)
    matches = df[df["association_id"] == association_id]
    if matches.empty:
        raise KeyError(f"No discharge found for association_id={association_id}")
    return matches.iloc[0]


def _row_to_features(row: pd.Series, model_feature_names: list[str]) -> dict[str, Any]:
    """Selects exactly the real model input columns from a pool row --
    never association_id/patient_id. deployment_get_info's feature list is
    the ground truth for what the model actually takes, not the pool's raw
    columns."""
    features: dict[str, Any] = {}
    for name in model_feature_names:
        value = row[name]
        if isinstance(value, pd.Timestamp):
            value = value.date().isoformat()
        features[name] = "" if pd.isna(value) else value
    return features


async def get_patient_features(config: Config, association_id: str) -> dict[str, Any]:
    row = get_patient_row(config, association_id)
    model_feature_names = await feature_groups.get_model_feature_names(config)
    return _row_to_features(row, model_feature_names)


async def _run_batch_scoring(config: Config) -> dict[str, dict[str, Any]]:
    submit = await call_tool(
        config,
        "predict_batch_predictions_from_dataset",
        {
            "deployment_id": config.readmission_deployment_id,
            "dataset_id": config.discharge_predictions_dataset_id,
        },
    )
    job_id = submit["job_id"]

    while True:
        status = await call_tool(config, "predict_get_batch_job_status", {"job_id": job_id})
        state = status["batch_job_status"]
        if state == "COMPLETED":
            break
        if state in ("FAILED", "ABORTED", "ERROR"):
            raise RuntimeError(f"Batch scoring job {job_id} failed: {status}")
        await asyncio.sleep(5)

    results = await call_tool(config, "predict_get_batch_results", {"job_id": job_id})
    reader = csv.DictReader(io.StringIO(results["data"]))
    scores: dict[str, dict[str, Any]] = {}
    for row in reader:
        risk_score = float(row["readmitted_True_PREDICTION"])
        scores[row["association_id"]] = {
            "risk_score": risk_score,
            "risk_tier": scoring.risk_tier(risk_score),
        }
    return scores


async def get_cached_scores(
    config: Config, force_refresh: bool = False
) -> dict[str, dict[str, Any]]:
    """association_id -> {risk_score, risk_tier} for the whole pool."""
    global _cached_scores, _cached_scores_at

    async with _batch_lock:
        is_stale = (time.monotonic() - _cached_scores_at) > _BATCH_CACHE_TTL_SECONDS
        if _cached_scores is None or is_stale or force_refresh:
            logger.info("Refreshing batch-scored risk tiers from Global MCP")
            _cached_scores = await _run_batch_scoring(config)
            _cached_scores_at = time.monotonic()
        return _cached_scores


async def get_queue(config: Config, as_of_date: str) -> list[dict[str, Any]]:
    """Today's discharge queue: pool rows on the as-of date, joined with
    cached batch-scored risk tiers. Sorted highest risk first."""
    df = get_pool_dataframe(config)
    day_df = df[df["discharge_date"].dt.date.astype(str) == as_of_date]
    scores = await get_cached_scores(config)

    rows: list[dict[str, Any]] = []
    for _, row in day_df.iterrows():
        association_id = row["association_id"]
        score = scores.get(association_id)
        rows.append(
            {
                "association_id": association_id,
                "patient_id": int(row["patient_id"]),
                "admission_date": row["admission_date"].date().isoformat(),
                "discharge_date": row["discharge_date"].date().isoformat(),
                "age": row["age"],
                "risk_score": score["risk_score"] if score else None,
                "risk_tier": score["risk_tier"] if score else None,
            }
        )
    rows.sort(key=lambda r: (r["risk_score"] is None, -(r["risk_score"] or 0)))
    return rows
