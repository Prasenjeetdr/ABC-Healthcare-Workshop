# Copyright 2025 DataRobot, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""score_and_explain -- the load-bearing prediction+explanation function.
Reused identically by the discharge-detail endpoint, the manual-entry
endpoint, what-if, and two chat tools -- one scoring path, so a result can
never disagree with itself.
"""

from __future__ import annotations

import csv
import io
from typing import Any

from app.config import Config
from app.discharges import feature_groups
from app.mcp_client import call_tool

# Risk tiers, defined once and imported everywhere else that needs them
# (chat, queue, what-if, recommendations).
LOW_RISK_MAX = 0.15
MEDIUM_RISK_MAX = 0.35


def risk_tier(risk_score: float) -> str:
    if risk_score < LOW_RISK_MAX:
        return "LOW"
    if risk_score < MEDIUM_RISK_MAX:
        return "MEDIUM"
    return "HIGH"


def _features_to_csv(features: dict[str, Any]) -> str:
    buffer = io.StringIO()
    writer = csv.DictWriter(buffer, fieldnames=list(features.keys()))
    writer.writeheader()
    writer.writerow(features)
    return buffer.getvalue()


def _parse_score_row(row: dict[str, str]) -> dict[str, Any]:
    risk_score = float(row["readmitted_True_PREDICTION"])
    explanations = []
    for i in (1, 2, 3):
        feature = row.get(f"EXPLANATION_{i}_FEATURE_NAME")
        if not feature:
            continue
        explanations.append(
            {
                "feature": feature,
                # Labelled here rather than at the grouping step, so every
                # consumer inherits it -- including the chat what_if_patient
                # tool, which returns this result to the LLM ungrouped and
                # would otherwise quote raw column names back to a clinician.
                "label": feature_groups.display_name(feature),
                "strength": float(row[f"EXPLANATION_{i}_STRENGTH"]),
                "actual_value": row[f"EXPLANATION_{i}_ACTUAL_VALUE"],
                "qualitative_strength": row[f"EXPLANATION_{i}_QUALITATIVE_STRENGTH"],
            }
        )
    return {
        "risk_score": risk_score,
        "risk_tier": risk_tier(risk_score),
        "explanations": explanations,
    }


async def score_and_explain(config: Config, features: dict[str, Any]) -> dict[str, Any]:
    """`features` is a plain dict of real model input values for one
    discharge -- the caller owns selecting them (see
    feature_groups.get_model_feature_names); this function does not filter."""
    csv_text = _features_to_csv(features)
    result = await call_tool(
        config,
        "predict_score_inline_realtime",
        {
            "deployment_id": config.readmission_deployment_id,
            "dataset": csv_text,
            "max_explanations": 3,
        },
    )
    reader = csv.DictReader(io.StringIO(result["data"]))
    row = next(reader)
    return _parse_score_row(row)


async def what_if(
    config: Config, baseline_features: dict[str, Any], overrides: dict[str, Any]
) -> dict[str, Any]:
    """Scores the baseline feature dict and the same dict with `overrides`
    merged in; returns both plus the delta. A plain dict merge -- no
    adjustment DSL. Every result here is visibly hypothetical: never fed to
    the recommendation generator, never logged as a real prediction."""
    baseline = await score_and_explain(config, baseline_features)
    adjusted = await score_and_explain(config, {**baseline_features, **overrides})
    return {
        "baseline": baseline,
        "adjusted": adjusted,
        "delta": adjusted["risk_score"] - baseline["risk_score"],
    }
