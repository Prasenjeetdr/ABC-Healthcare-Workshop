# Copyright 2025 DataRobot, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Explainability grouping and the deployment's real feature schema.

Buckets score_and_explain's per-feature explanation output into clinical
domains, server-side, using this project's real, verified feature-group
mapping (config/feature_group_mapping.json) -- never duplicated into the
frontend. The same file carries the human-readable label for each raw column
name, and `display_name` is the single source for those: they reach the UI as
a `label` on every explanation and schema field, and the agent prompt uses
them too, so no raw column name ever reaches a clinician or the model. Also
caches deployment_get_info, the ground truth for the
manual-entry form's field set (not the predictions pool's raw columns,
which include non-model identifiers like patient_id/association_id).
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
import time
from pathlib import Path
from typing import Any

from app.config import Config
from app.mcp_client import call_tool

logger = logging.getLogger(__name__)

_MAPPING_PATH = Path(__file__).parent.parent / "config" / "feature_group_mapping.json"
_OTHER_GROUP = "Other"

with open(_MAPPING_PATH) as _f:
    _MAPPING = json.load(_f)

_GROUPS: dict[str, list[str]] = _MAPPING["groups"]
_LABELS: dict[str, str] = _MAPPING.get("labels", {})

_FEATURE_TO_GROUP: dict[str, str] = {
    feature: group for group, features in _GROUPS.items() for feature in features
}

_CACHE_TTL_SECONDS = 15 * 60
_cache_lock = asyncio.Lock()
_cached_info: dict[str, Any] | None = None
_cached_at: float = 0.0


def group_for_feature(feature_name: str) -> str:
    return _FEATURE_TO_GROUP.get(feature_name, _OTHER_GROUP)


def display_name(feature_name: str) -> str:
    """The clinician-facing label for a raw dataset column name.

    Explicit labels in the mapping cover the codes, counters and
    abbreviations (`A1Cresult`, `diag_1_desc`, `number_inpatient`). Anything
    else falls back to a title-cased transform, which already reads correctly
    for the ~25 medication columns (`metformin` -> `Metformin`), so those
    need no hand-written entries.
    """
    explicit = _LABELS.get(feature_name)
    if explicit:
        return explicit
    spaced = feature_name.replace("_", " ")
    # Split camelCase too, so a stray `maxGluSerum`-style name still reads.
    spaced = re.sub(r"([a-z])([A-Z])", r"\1 \2", spaced)
    return " ".join(word[:1].upper() + word[1:] for word in spaced.split())


def group_explanations(explanations: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Buckets a score_and_explain() explanation list by clinical domain.
    A feature not in the mapping falls into a visible "Other" bucket,
    never silently vanishes."""
    grouped: dict[str, list[dict[str, Any]]] = {}
    for explanation in explanations:
        group = group_for_feature(explanation["feature"])
        # scoring.py labels explanations at the source; this only fills one
        # in for a caller that built an explanation dict by hand.
        labelled = {"label": display_name(explanation["feature"]), **explanation}
        grouped.setdefault(group, []).append(labelled)
    return [{"group": group, "explanations": items} for group, items in grouped.items()]


async def get_deployment_info(config: Config, force_refresh: bool = False) -> dict[str, Any]:
    """Cached deployment_get_info -- model_type, target, and a
    feature-importance-ranked real input list."""
    global _cached_info, _cached_at

    async with _cache_lock:
        is_stale = (time.monotonic() - _cached_at) > _CACHE_TTL_SECONDS
        if _cached_info is None or is_stale or force_refresh:
            logger.info("Refreshing deployment schema from Global MCP")
            _cached_info = await call_tool(
                config,
                "deployment_get_info",
                {"deployment_id": config.readmission_deployment_id},
            )
            _cached_at = time.monotonic()
        return _cached_info


async def get_model_feature_names(config: Config) -> list[str]:
    info = await get_deployment_info(config)
    return [feature["name"] for feature in info["features"]]
