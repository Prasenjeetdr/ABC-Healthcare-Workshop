# Copyright 2025 DataRobot, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Loads and aggregates the readmission cohort history (Phase 1).

History = the training dataset (Jan 2025-Jun 2026) concatenated with the
actuals dataset (Jul 2026-Dec 2026) -- both carry a known `readmitted`
outcome, so together they form one continuous history with no predictions
involved.
"""

import logging
import threading
import time
from dataclasses import dataclass

import datarobot as dr
import pandas as pd

from app.config import Config

logger = logging.getLogger(__name__)

# Cohort baseline cited throughout the demo narrative -- distinct from the
# rate actually observed in the loaded history (exposed separately), since
# the two are expected to differ slightly.
COHORT_BASELINE_RATE = 0.3965

# Segment dimensions the dashboard can filter and break down by.
SEGMENT_DIMENSIONS = (
    "race",
    "gender",
    "age",
    "discharge_disposition_id",
    "admission_type_id",
)

_AGE_BAND_ORDER = [f"[{start}-{start + 10})" for start in range(0, 100, 10)]

_CACHE_TTL_SECONDS = 15 * 60

_cache_lock = threading.Lock()
_cached_df: pd.DataFrame | None = None
_cached_at: float = 0.0


def _get_client(config: Config) -> dr.Client:
    return dr.Client(
        token=config.resolve_datarobot_api_token(),
        endpoint=config.resolve_datarobot_endpoint(),
    )


def _fetch_dataset(dataset_id: str, client: dr.Client) -> pd.DataFrame:
    dataset = dr.Dataset.get(dataset_id)
    return dataset.get_as_dataframe()


def _age_sort_key(value: object) -> int:
    try:
        return _AGE_BAND_ORDER.index(str(value))
    except ValueError:
        return len(_AGE_BAND_ORDER)


def _load_history_dataframe(config: Config) -> pd.DataFrame:
    client = _get_client(config)

    training = _fetch_dataset(config.discharge_training_dataset_id, client)
    actuals = _fetch_dataset(config.discharge_actuals_dataset_id, client)

    history = pd.concat([training, actuals], ignore_index=True, sort=False)
    history["admission_date"] = pd.to_datetime(history["admission_date"])
    history["discharge_date"] = pd.to_datetime(history["discharge_date"])
    history["readmitted"] = history["readmitted"].astype(bool)

    # The actuals dataset extends into 2026-12; Phase 1 is "history," so it must
    # never show discharges beyond today, even though the underlying data does.
    today = pd.Timestamp.now().normalize()
    history = history[history["admission_date"] <= today]

    # A patient who died in the hospital cannot be readmitted, so an "Expired"
    # discharge isn't a meaningful data point for a 30-day readmission cohort.
    history = history[history["discharge_disposition_id"] != "Expired"]

    return history


def get_history_dataframe(config: Config, force_refresh: bool = False) -> pd.DataFrame:
    """Returns the cached history dataframe, refreshing it if it's stale or missing."""
    global _cached_df, _cached_at

    with _cache_lock:
        is_stale = (time.monotonic() - _cached_at) > _CACHE_TTL_SECONDS
        if _cached_df is None or is_stale or force_refresh:
            logger.info("Refreshing cohort history from AI Catalog")
            _cached_df = _load_history_dataframe(config)
            _cached_at = time.monotonic()
        return _cached_df


@dataclass(frozen=True)
class HistoryFilters:
    start_date: pd.Timestamp | None = None
    end_date: pd.Timestamp | None = None
    race: tuple[str, ...] | None = None
    gender: tuple[str, ...] | None = None
    age: tuple[str, ...] | None = None
    discharge_disposition_id: tuple[str, ...] | None = None
    admission_type_id: tuple[str, ...] | None = None

    def segment_values(self, dimension: str) -> tuple[str, ...] | None:
        return getattr(self, dimension, None)


def apply_filters(df: pd.DataFrame, filters: HistoryFilters) -> pd.DataFrame:
    mask = pd.Series(True, index=df.index)

    if filters.start_date is not None:
        mask &= df["admission_date"] >= filters.start_date
    if filters.end_date is not None:
        mask &= df["admission_date"] <= filters.end_date

    for dimension in SEGMENT_DIMENSIONS:
        values = filters.segment_values(dimension)
        if values:
            mask &= df[dimension].isin(values)

    return df[mask]


def summarize(df: pd.DataFrame) -> dict[str, object]:
    total_encounters = len(df)
    readmitted_count = int(df["readmitted"].sum())
    observed_rate = readmitted_count / total_encounters if total_encounters else 0.0

    return {
        "total_patients": int(df["patient_id"].nunique()) if total_encounters else 0,
        "total_encounters": total_encounters,
        "readmitted_count": readmitted_count,
        "observed_rate": observed_rate,
        "baseline_rate": COHORT_BASELINE_RATE,
        "date_min": df["admission_date"].min().date().isoformat() if total_encounters else None,
        "date_max": df["admission_date"].max().date().isoformat() if total_encounters else None,
    }


def monthly_trend(df: pd.DataFrame) -> list[dict[str, object]]:
    if df.empty:
        return []

    month = df["admission_date"].dt.to_period("M")
    grouped = df.groupby(month)["readmitted"].agg(["size", "sum"]).reset_index()
    grouped.columns = ["month", "encounters", "readmitted_count"]
    grouped["rate"] = grouped["readmitted_count"] / grouped["encounters"]
    grouped["month"] = grouped["month"].astype(str)
    grouped = grouped.sort_values("month")

    return grouped.to_dict(orient="records")


def segment_breakdown(df: pd.DataFrame, dimension: str) -> list[dict[str, object]]:
    if dimension not in SEGMENT_DIMENSIONS:
        raise ValueError(f"Unsupported segment dimension: {dimension}")
    if df.empty:
        return []

    grouped = df.groupby(dimension)["readmitted"].agg(["size", "sum"]).reset_index()
    grouped.columns = ["segment", "encounters", "readmitted_count"]
    grouped["rate"] = grouped["readmitted_count"] / grouped["encounters"]

    if dimension == "age":
        grouped = grouped.sort_values("segment", key=lambda s: s.map(_age_sort_key))
    else:
        grouped = grouped.sort_values("rate", ascending=False)

    return grouped.to_dict(orient="records")


def filter_options(df: pd.DataFrame) -> dict[str, object]:
    options: dict[str, object] = {}
    for dimension in SEGMENT_DIMENSIONS:
        values = df[dimension].dropna().unique().tolist()
        if dimension == "age":
            values.sort(key=_age_sort_key)
        else:
            values.sort()
        options[dimension] = values

    options["date_min"] = df["admission_date"].min().date().isoformat() if not df.empty else None
    options["date_max"] = df["admission_date"].max().date().isoformat() if not df.empty else None
    return options


PATIENT_TABLE_COLUMNS = [
    "patient_id",
    "admission_date",
    "discharge_date",
    "age",
    "race",
    "gender",
    "discharge_disposition_id",
    "admission_type_id",
    "time_in_hospital",
    "num_medications",
    "number_inpatient",
    "readmitted",
]

_SORTABLE_COLUMNS = set(PATIENT_TABLE_COLUMNS)


def patient_rows(
    df: pd.DataFrame,
    offset: int,
    limit: int,
    sort_by: str = "admission_date",
    sort_dir: str = "desc",
) -> tuple[list[dict[str, object]], int]:
    if sort_by not in _SORTABLE_COLUMNS:
        sort_by = "admission_date"

    total = len(df)
    sorted_df = df.sort_values(sort_by, ascending=(sort_dir == "asc"))
    page = sorted_df.iloc[offset : offset + limit][PATIENT_TABLE_COLUMNS].copy()

    page["admission_date"] = page["admission_date"].dt.date.astype(str)
    page["discharge_date"] = page["discharge_date"].dt.date.astype(str)

    return page.to_dict(orient="records"), total
