#!/usr/bin/env bash

# Configure environment
export UV_CACHE_DIR=.uv

# Get the number of CPU cores
if [ -f /sys/fs/cgroup/cpu.max ] && ! grep -q "max" /sys/fs/cgroup/cpu.max; then
    read -r max period < /sys/fs/cgroup/cpu.max
    cpu_cores=$((max / period))
else
    cpu_cores=$(nproc)
fi

# Calculate the recommended number of workers
workers=$((cpu_cores * 2 + 1))

# Ensure at least 2 workers are started
if [[ $workers -lt 2 ]]; then
  workers=2
fi

# Single worker on purpose -- for read-your-writes consistency, NOT durability.
# The recommendations SQLite file is synced via connect_dr_fs, which downloads a
# copy when a connection opens and only uploads it again on close(). Each worker
# holds its own connection, so with N workers there are N divergent local copies:
# a recommendation drafted on one worker can be invisible to a read served by
# another. One worker removes that.
#
# It does NOT make the data survive a redeploy -- measured, it doesn't. close()
# is the only upload point, and a container replacement doesn't reliably run it,
# so writes since startup are lost either way. The real fix is a managed
# database (PostgreSQL); see app/recommendations/db.py.
workers=1

if [ ! -d ".venv" ]; then
    uv sync
fi

echo "Starting App with ${workers} workers"
uv run uvicorn app.main:app --workers "$workers" --host 0.0.0.0 --port 8080 --proxy-headers --timeout-keep-alive 300
